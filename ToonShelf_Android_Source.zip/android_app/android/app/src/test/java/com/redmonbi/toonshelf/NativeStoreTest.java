package com.redmonbi.toonshelf;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.json.*;
import android.net.Uri;
import java.io.*;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=35)
public class NativeStoreTest {
    QueueStore store;
    @Before public void setup()throws Exception{store=new QueueStore(RuntimeEnvironment.getApplication());store.write(new JSONObject().put("jobs",new JSONArray()).put("settings",new JSONObject()));}
    JSONObject work()throws Exception{return new JSONObject().put("title","테스트 작품").put("url","https://example.org/webtoon/7");}
    @Test public void duplicateAndDurableProgress()throws Exception{JSONObject first=store.enqueue(work(),10),second=store.enqueue(work(),10);assertEquals(first.getString("id"),second.getString("id"));String id=first.getString("id");store.update(id,new JSONObject().put("progress",55).put("status","paused"));assertEquals("paused",new QueueStore(RuntimeEnvironment.getApplication()).status(id));assertEquals(55,store.find(id).getInt("progress"));assertNull(store.next());}
    @Test public void priorityAndAtomicClaim()throws Exception{JSONObject a=store.enqueue(work(),1),b=store.enqueue(work(),10);store.update(b.getString("id"),new JSONObject().put("priority",999));assertEquals(b.getString("id"),store.claimNext().getString("id"));assertEquals(a.getString("id"),store.claimNext().getString("id"));assertNull(store.claimNext());store.recover();assertEquals("waiting",store.status(b.getString("id")));}
    @Test public void timeWindowsCrossMidnight()throws Exception{JSONObject off=new JSONObject();assertTrue(DownloadWorker.inAllowedWindow(off));assertEquals(1439,DownloadWorker.minute("23:59"));assertTrue(DownloadWorker.inAllowedWindow(new JSONObject().put("window_enabled",true).put("start","03:00").put("end","03:00")));}
    @Test public void imageJournalRecognizesIncompleteFiles()throws Exception{ImageLedger ledger=new ImageLedger(RuntimeEnvironment.getApplication());Uri u=Uri.parse("content://fixture/1");assertFalse(ledger.owned(u));ledger.record(u,"",false,"w","ep");assertTrue(ledger.owned(u));assertFalse(ledger.valid(RuntimeEnvironment.getApplication().getContentResolver(),u));assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",ImageLedger.hash(new ByteArrayInputStream("abc".getBytes())));ledger.close();}
    @Test public void episodeParserOrdersNumericallyAndKeepsDates()throws Exception{String html="<a href='/webtoons/7/ten.html'>작품 10화 2026-10-10</a><a href='/webtoons/7/two.html'>작품 2화 2026-10-09</a>";java.util.List<JSONObject> rows=DownloadWorker.episodes(org.jsoup.Jsoup.parse(html,"https://example.org/"),"작품","w");assertEquals(2,rows.size());assertEquals(2,rows.get(0).getInt("number"));assertEquals("2026-10-10",rows.get(1).getString("date"));}
    @Test public void scannerCancellationDoesNotTouchDocuments()throws Exception{java.util.concurrent.atomic.AtomicBoolean flag=new java.util.concurrent.atomic.AtomicBoolean(true);TreeIndexer index=new TreeIndexer(RuntimeEnvironment.getApplication(),Uri.parse("content://fixture/tree/root"),flag,(f,d)->{});try{index.scan();fail();}catch(java.util.concurrent.CancellationException expected){}}
}

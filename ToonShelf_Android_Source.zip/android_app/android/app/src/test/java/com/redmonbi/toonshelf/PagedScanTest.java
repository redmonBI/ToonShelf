package com.redmonbi.toonshelf;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import android.net.Uri;
import android.provider.DocumentsContract;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class) @Config(sdk={34,35})
public class PagedScanTest {
    final android.content.Context context=RuntimeEnvironment.getApplication();
    TreeIndexer fixture(int chapters,int images,AtomicBoolean cancelled,TreeIndexer.Progress progress){
        return new TreeIndexer(context,Uri.parse("content://paged/tree/root"),cancelled,progress){
            @Override public List<Entry> children(Uri folder,String prefix){String id=DocumentsContract.getDocumentId(folder);List<Entry> rows=new ArrayList<>();String dir=DocumentsContract.Document.MIME_TYPE_DIR;
                if(id.equals("root")){rows.add(entry("작품","작품",dir,"work"));}
                else if(id.equals("work")){for(int i=0;i<chapters;i++)rows.add(entry("작품/"+i+"화",i+"화",dir,"chapter"+i));}
                else if(id.startsWith("chapter")){int n=Integer.parseInt(id.substring(7));for(int i=images;i>0;i--)rows.add(entry("작품/"+n+"화/"+i+".jpg",i+".jpg","image/jpeg",id+"image"+i));}
                return rows;
            }
        };
    }
    TreeIndexer.Entry entry(String path,String name,String mime,String id){return new TreeIndexer.Entry(path,name,mime,DocumentsContract.buildDocumentUri("paged",id),100,0);}
    @Test public void largeLibraryReturnsSummariesAndOnlyRequestedChunk()throws Exception{
        // More images than the old all-in-memory 150,000-image ceiling.
        JSONObject result=fixture(950,160,new AtomicBoolean(),(f,d)->{}).scanPaged();
        assertEquals(152000,result.getInt("files"));assertTrue(result.getBoolean("paged"));assertTrue(result.toString().length()<1024*1024);
        JSONArray chapters=result.getJSONArray("works").getJSONObject(0).getJSONArray("chapters");assertEquals(950,chapters.length());
        JSONObject first=chapters.getJSONObject(0);assertFalse(first.has("nativePages"));assertEquals(160,first.getInt("count"));
        JSONArray chunk=ChapterPages.read(context,first.getString("page_ref"),0).getJSONArray("pages");assertEquals(128,chunk.length());assertEquals("1.jpg",chunk.getJSONObject(0).getString("name"));
        assertEquals(32,ChapterPages.read(context,first.getString("page_ref"),128).getJSONArray("pages").length());
        assertEquals(160,ChapterPages.all(context,first).length());ChapterPages.cleanup(context,"");
    }
    @Test public void cancellationDiscardsNewGenerationAndKeepsPriorPages()throws Exception{
        JSONObject good=fixture(1,2,new AtomicBoolean(),(f,d)->{}).scanPaged();String reference=good.getJSONArray("works").getJSONObject(0).getJSONArray("chapters").getJSONObject(0).getString("page_ref");
        AtomicBoolean stop=new AtomicBoolean();try{fixture(20,100,stop,(f,d)->{if(f>=100)stop.set(true);}).scanPaged();fail();}catch(java.util.concurrent.CancellationException expected){}
        assertEquals(2,ChapterPages.read(context,reference,0).getJSONArray("pages").length());
        File[] generations=new File(context.getFilesDir(),"library-pages").listFiles();assertEquals(1,generations.length);ChapterPages.cleanup(context,"");
    }
    @Test public void isolatedUnreadableFolderDoesNotAbortOtherWorks()throws Exception{
        TreeIndexer index=new TreeIndexer(context,Uri.parse("content://paged/tree/root"),new AtomicBoolean(),(f,d)->{}){
            @Override public List<Entry> children(Uri folder,String prefix)throws Exception{String id=DocumentsContract.getDocumentId(folder);if(id.equals("root"))return Arrays.asList(entry("bad","bad",DocumentsContract.Document.MIME_TYPE_DIR,"bad"),entry("good","good",DocumentsContract.Document.MIME_TYPE_DIR,"good"));if(id.equals("bad"))throw new IOException("permission");return Arrays.asList(entry("good/a.jpg","a.jpg","image/jpeg","a"));}
        };
        JSONObject value=index.scanPaged();assertEquals(1,value.getJSONArray("works").length());assertEquals(1,value.getJSONArray("warnings").length());ChapterPages.cleanup(context,"");
    }
    @Test public void pageReferenceCannotReadOutsidePrivateCache()throws Exception{
        for(String reference:Arrays.asList("../../secret","/data/private","bad"))try{ChapterPages.read(context,reference,0);fail();}catch(IOException expected){}
    }
    @Test public void diskPlansReplaceOldPathsAndKeepMissingPositions()throws Exception{
        TreeIndexer scanner=fixture(1,2,new AtomicBoolean(),(f,d)->{}) ;
        try(ScanStore store=new ScanStore(context)){scanner.spool=store;Map<String,JSONObject> map=store.records;
            map.put("old/a.jpg",new JSONObject().put("episode_key","ep").put("position",8));
            scanner.consume(new JSONObject().put("work","작품").put("episode","1화").put("episode_key","ep").put("images",new JSONArray().put(new JSONObject().put("file","a.jpg").put("position",1)).put(new JSONObject().put("file","missing.jpg").put("position",2))),"new/",map);
            assertFalse(map.containsKey("old/a.jpg"));assertEquals(2,map.get("new/missing.jpg").getInt("position"));
        }
    }
}

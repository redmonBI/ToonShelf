package com.redmonbi.toonshelf;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import org.json.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=35)
public class TreeIndexTest {
    @Test public void recursiveRootUsesPcOrderAndCompleteInventory()throws Exception{
        Uri tree=Uri.parse("content://fixture/tree/root");Map<String,List<TreeIndexer.Entry>> fixtureFolders=new HashMap<>();String dir=DocumentsContract.Document.MIME_TYPE_DIR;
        fixtureFolders.put("root",Arrays.asList(e("작품","작품",dir,"work",0),e("state","state",dir,"state",0)));
        fixtureFolders.put("work",Arrays.asList(e("작품/10화","10화",dir,"ten",0),e("작품/2화","2화",dir,"two",0)));
        fixtureFolders.put("ten",Arrays.asList(e("작품/10화/10.jpg","10.jpg","image/jpeg","a",20)));
        fixtureFolders.put("two",Arrays.asList(e("작품/2화/10.jpg","10.jpg","image/jpeg","b",30),e("작품/2화/2.jpg","2.jpg","image/jpeg","c",40)));
        TreeIndexer scanner=new TreeIndexer(RuntimeEnvironment.getApplication(),tree,new AtomicBoolean(),(f,d)->{}){
            @Override public List<Entry> children(Uri folder,String prefix){return fixtureFolders.getOrDefault(DocumentsContract.getDocumentId(folder),Collections.emptyList());}
            @Override Map<String,JSONObject> pcRecords()throws Exception{Map<String,JSONObject> m=new HashMap<>();for(String p:Arrays.asList("작품/10화/10.jpg","작품/2화/10.jpg","작품/2화/2.jpg")){boolean ten=p.contains("10화");m.put(p,new JSONObject().put("work_key","/webtoon/7").put("url","https://example.org/webtoon/7").put("title","작품").put("episode_key",ten?"ep10":"ep2").put("folder",ten?"10화":"2화").put("position",p.endsWith("2.jpg")?2:1).put("sequence",ten?10:2).put("expected_images",ten?1:2).put("expected_episode_keys",new JSONArray(Arrays.asList("ep2","ep10"))).put("publisher","네이버").put("genre","판타지").put("weekdays",new JSONArray(Arrays.asList(0,4))).put("upload_date","2026-10-11"));}return m;}
        };
        JSONObject result=scanner.scan();assertEquals(4,result.getInt("folders"));JSONObject work=result.getJSONArray("works").getJSONObject(0);assertTrue(work.getBoolean("complete"));assertEquals("네이버",work.getString("publisher"));assertEquals(2,work.getJSONArray("weekdays").length());JSONObject ep=work.getJSONArray("chapters").getJSONObject(0);assertEquals("2화",ep.getString("label"));assertEquals("10.jpg",ep.getJSONArray("nativePages").getJSONObject(0).getString("name"));assertEquals(70,ep.getInt("size"));assertFalse(scanner.files.keySet().stream().anyMatch(p->p.startsWith("state/")));
    }
    TreeIndexer.Entry e(String p,String n,String mime,String id,long size){return new TreeIndexer.Entry(p,n,mime,DocumentsContract.buildDocumentUri("fixture",id),size,0);}
}

package com.redmonbi.toonshelf;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import org.json.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=35)
public class TreeIndexTest {
    @Test public void recursiveRootUsesPcOrderAndCompleteInventory()throws Exception{
        Uri tree=Uri.parse("content://fixture/tree/root");Map<String,List<TreeIndexer.Entry>> fixtureFolders=new HashMap<>();String dir=DocumentsContract.Document.MIME_TYPE_DIR;
        fixtureFolders.put("root",Arrays.asList(e("작품","작품",dir,"work",0),e("state","state",dir,"state",0)));
        fixtureFolders.put("work",Arrays.asList(e("작품/10화","10화",dir,"ten",0),e("작품/2화","2화",dir,"two",0)));
        fixtureFolders.put("ten",Arrays.asList(e("작품/10화/10.jpg","10.jpg","image/jpeg","a",20)));
        fixtureFolders.put("two",Arrays.asList(e("작품/2화/10.jpg","10.jpg","image/jpeg","b",30),e("작품/2화/2.jpg","2.jpg","image/jpeg","c",40)));
        TreeIndexer scanner=new TreeIndexer(RuntimeEnvironment.getApplication(),tree,new AtomicBoolean(),(f,d)->{}){
            @Override public List<Entry> children(Uri folder,String prefix){return fixtureFolders.getOrDefault(DocumentsContract.getDocumentId(folder),Collections.emptyList());}
            @Override Map<String,JSONObject> pcRecords()throws Exception{Map<String,JSONObject> m=new HashMap<>();for(String p:Arrays.asList("작품/10화/10.jpg","작품/2화/10.jpg","작품/2화/2.jpg")){boolean ten=p.contains("10화");m.put(p,new JSONObject().put("work_key","/webtoon/7").put("url","https://example.org/webtoon/7").put("title","작품").put("episode_key",ten?"ep10":"ep2").put("folder",ten?"10화":"2화").put("position",p.endsWith("2.jpg")?2:1).put("sequence",ten?10:2).put("expected_images",ten?1:2).put("expected_episode_keys",new JSONArray(Arrays.asList("ep2","ep10"))).put("publisher","네이버").put("genre","판타지").put("weekdays",new JSONArray(Arrays.asList(0,4))).put("upload_date","2026-10-11"));}return m;}
        };
        JSONObject result=scanner.scan();assertEquals(4,result.getInt("folders"));JSONObject work=result.getJSONArray("works").getJSONObject(0);assertTrue(work.getBoolean("complete"));assertEquals("네이버",work.getString("publisher"));assertEquals(2,work.getJSONArray("weekdays").length());JSONObject ep=work.getJSONArray("chapters").getJSONObject(0);assertEquals("2화",ep.getString("label"));assertEquals("10.jpg",ep.getJSONArray("nativePages").getJSONObject(0).getString("name"));assertEquals(70,ep.getInt("size"));assertFalse(scanner.files.keySet().stream().anyMatch(p->p.startsWith("state/")));
    }
    @Test public void authoritativePlanExcludesOldFilesAndKeepsMissingOrdinal()throws Exception{
        Uri tree=Uri.parse("content://plan-fixture/tree/root");TreeIndexer scanner=new TreeIndexer(RuntimeEnvironment.getApplication(),tree,new AtomicBoolean(),(f,d)->{}){
            @Override public List<Entry> children(Uri folder,String prefix){String id=DocumentsContract.getDocumentId(folder);String dir=DocumentsContract.Document.MIME_TYPE_DIR;if(id.equals("root"))return Arrays.asList(e("작품","작품",dir,"work",0));if(id.equals("work"))return Arrays.asList(e("작품/1화","1화",dir,"episode",0));if(id.equals("episode"))return Arrays.asList(e("작품/1화/10.jpg","10.jpg","image/jpeg","image",20),e("작품/1화/old.jpg","old.jpg","image/jpeg","old",10));return Collections.emptyList();}
            @Override void sidecars(Map<String,JSONObject> map){try{consume(new JSONObject().put("work","작품").put("work_key","w").put("episode","1화").put("episode_key","ep").put("images",new JSONArray().put(new JSONObject().put("file","missing.jpg").put("position",1)).put(new JSONObject().put("file","10.jpg").put("position",2))),"작품/1화/",map);}catch(Exception e){throw new IllegalStateException(e);}}
        };
        JSONObject chapter=scanner.scan().getJSONArray("works").getJSONObject(0).getJSONArray("chapters").getJSONObject(0);JSONArray pages=chapter.getJSONArray("nativePages");assertEquals(2,pages.length());assertTrue(pages.getJSONObject(0).getBoolean("missing"));assertEquals("10.jpg",pages.getJSONObject(1).getString("name"));assertEquals(1,chapter.getInt("missing"));
    }
    @Test public void invalidPlanCannotOverrideGoodRecords()throws Exception{
        TreeIndexer scanner=new TreeIndexer(RuntimeEnvironment.getApplication(),Uri.parse("content://plan-fixture/tree/root"),new AtomicBoolean(),(f,d)->{});Map<String,JSONObject> map=new HashMap<>();map.put("work/ep/a.jpg",new JSONObject().put("position",7));JSONObject bad=new JSONObject().put("work","work").put("episode","ep").put("images",new JSONArray().put(new JSONObject().put("file","a.jpg").put("position",1)).put(new JSONObject().put("file","b.jpg").put("position",1)));try{scanner.consume(bad,"work/ep/",map);fail("Duplicate ordinal accepted");}catch(java.io.IOException expected){}assertEquals(7,map.get("work/ep/a.jpg").getInt("position"));assertFalse(scanner.plannedFolders.contains("work/ep/"));
    }
    @Test public void metadataFilesDoNotConsumeImageCapacity()throws Exception{TreeIndexer.validateCounts(148796,150500);try{TreeIndexer.validateCounts(150001,150001);fail("Image limit not enforced");}catch(java.io.IOException expected){}}
    TreeIndexer.Entry e(String p,String n,String mime,String id,long size){return new TreeIndexer.Entry(p,n,mime,DocumentsContract.buildDocumentUri("fixture",id),size,0);}
}

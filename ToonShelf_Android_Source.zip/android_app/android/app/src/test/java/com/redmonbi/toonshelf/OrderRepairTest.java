package com.redmonbi.toonshelf;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.json.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk={34,35})
public class OrderRepairTest {
    @Test public void copiedFolderUsesSiteOrderWithMissingPlaceholderAndPreservesNames()throws Exception{
        String root="content://repair/"+UUID.randomUUID();OrderRepair repair=new OrderRepair(RuntimeEnvironment.getApplication(),root,new AtomicBoolean(),label->{}){
            @Override Document workPage(String url){return Jsoup.parse("<a href='/webtoons/7/1.html'>작품 1화 2026-10-13</a>","https://fixture.org/");}
            @Override Document page(String url){return Jsoup.parse("<div id='toon_content_imgs'><img data-original='https://cdn.test/900.jpg'><img data-original='https://cdn.test/missing.jpg'><img data-original='https://cdn.test/100.jpg'></div>",url);}
        };
        JSONArray pages=new JSONArray().put(new JSONObject().put("name","100.jpg").put("relative_path","작품/1화/100.jpg")).put(new JSONObject().put("name","900.jpg").put("relative_path","작품/1화/900.jpg"));JSONObject work=new JSONObject().put("key","/webtoon/7.html").put("title","작품").put("url","https://old.example/webtoon/7.html").put("chapters",new JSONArray().put(new JSONObject().put("key","/folder/작품|1화").put("label","1화").put("nativePages",pages)));
        JSONObject report=repair.repair(work,"https://fixture.org");assertEquals(report.toString(),1,report.getInt("checked"));JSONObject record=new ReadingRecords(RuntimeEnvironment.getApplication(),root).all().get(0);JSONArray images=record.getJSONArray("images");assertEquals("900.jpg",images.getJSONObject(0).getString("file"));assertTrue(images.getJSONObject(1).getBoolean("missing"));assertEquals("100.jpg",images.getJSONObject(2).getString("file"));assertEquals(1,record.getInt("sequence"));assertEquals("100.jpg",pages.getJSONObject(0).getString("name"));
    }
}

package com.redmonbi.toonshelf;
import org.junit.Test;import static org.junit.Assert.*;
public class OrderTest {
 @Test public void numericNamesPreserveReadingOrder(){assertTrue(Order.compare("2화","10화")<0);assertTrue(Order.compare("1-2화","1-10화")<0);assertTrue(Order.compare("a9999999999999999999999.jpg","a10000000000000000000000.jpg")<0);}
 @Test public void externalPathsRejected(){for(String p:new String[]{"../x.jpg","a/../../x.jpg","C:\\x.jpg","/etc/x"}){try{Order.relative(p);fail(p);}catch(IllegalArgumentException expected){}}assertEquals("작품/1화/2.jpg",Order.relative("작품\\1화\\2.jpg"));}
 @Test public void onlyRasterImages(){assertTrue(Order.image("IMAGE.JPG"));assertFalse(Order.image("x.svg"));assertFalse(Order.image("x.html"));}
}

package com.redmonbi.toonshelf;
import android.content.*;import android.content.pm.ProviderInfo;import android.database.*;import android.net.Uri;import android.os.*;import android.provider.DocumentsContract;import androidx.work.*;import androidx.work.testing.TestWorkerBuilder;import org.json.*;import org.jsoup.Jsoup;import org.jsoup.nodes.Document;import org.junit.*;import org.junit.runner.RunWith;import org.robolectric.*;import org.robolectric.annotation.Config;import org.robolectric.shadows.ShadowContentResolver;import java.io.*;import java.net.InetSocketAddress;import java.util.*;import java.util.concurrent.*;import com.sun.net.httpserver.HttpServer;import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk={34,35})
public class DownloadFlowTest {
 static File directory;static String origin;static int received;static boolean refuse;
 static final byte[] PNG=Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAHgAAAC0CAIAAADQLH9KAAABn0lEQVR4nO3SQQ0AIAADMcA7gggGUcG9WgNLLpv7nsF/K9hA6I5HR4SOCB0ROiJ0ROiI0BGhI0JHhI4IHRE6InRE6IjQEaEjQkeEjggdEToidEToiNARoSNCR4SOCB0ROiJ0ROiI0BGhI0JHhI4IHRE6InRE6IjQEaEjQkeEjggdEToidEToiNARoSNCR4SOCB0ROiJ0ROiI0BGhI0JHhI4IHRE6InRE6IjQEaEjQkeEjggdEToidEToiNARoSNCR4SOCB0ROiJ0ROiI0BGhI0JHhI4IHRE6InRE6IjQEaEjQkeEjggdEToidEToiNARoSNCR4SOCB0ROiJ0ROiI0BGhI0JHhI4IHRE6InRE6IjQEaEjQkeEjggdEToidEToiNARoSNCR4SOCB0ROiJ0ROiI0BGhI0JHhI4IHRE6InRE6IjQEaEjQkeEjggdEToidEToiNARoSNCR4SOCB0ROiJ0ROiI0BGhI0JHhI4IHRE6InRE6IjQEaEjQkeEjggdEToidEToiNARoSNCR4SOCB0ROiJ0ROiI0BGhI0KPxgNzwgNRMawuvwAAAABJRU5ErkJggg==");
 HttpServer server;ExecutorService executor;Context context;
 @Before public void setup()throws Exception{
  context=RuntimeEnvironment.getApplication();directory=new File(context.getCacheDir(),"download-fixture-"+UUID.randomUUID());assertTrue(directory.mkdir());
  context.getSharedPreferences("library",0).edit().clear().putString("root","content://fixture/tree/root").commit();
  new QueueStore(context).write(new JSONObject().put("jobs",new JSONArray()).put("settings",new JSONObject()));
  FixtureProvider provider=new FixtureProvider();ProviderInfo info=new ProviderInfo();info.authority="fixture";provider.attachInfo(context,info);ShadowContentResolver.registerProviderInternal("fixture",provider);context.getContentResolver().takePersistableUriPermission(Uri.parse("content://fixture/tree/root"),Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
  received=0;refuse=false;server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);server.createContext("/image.jpg",exchange->{received++;int status=refuse?403:200;exchange.sendResponseHeaders(status,PNG.length);exchange.getResponseBody().write(PNG);exchange.close();});server.start();origin="http://127.0.0.1:"+server.getAddress().getPort();executor=Executors.newSingleThreadExecutor();
 }
 @After public void stop(){server.stop(0);executor.shutdownNow();}
 public static class FixtureWorker extends DownloadWorker{
  public FixtureWorker(Context c,WorkerParameters p){super(c,p);}
  @Override Document page(String address,String selector,String id){String html=address.contains("/webtoon/")?"<a href='/webtoons/7/1.html'>UP 작품 1화 2026-10-12</a>":"<div id='toon_content_imgs'><img data-original='"+origin+"/image.jpg'></div>";return Jsoup.parse(html,origin+"/");}
 }
 void execute(JSONObject job)throws Exception{
  FixtureWorker worker=(FixtureWorker)TestWorkerBuilder.from(context,FixtureWorker.class,executor).build();Future<?> run=executor.submit(()->{try{worker.run(job);}catch(Exception e){throw new RuntimeException(e);}});long until=System.currentTimeMillis()+15000;
  while(!run.isDone()&&System.currentTimeMillis()<until){Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.sleep(10);}run.get(1,TimeUnit.SECONDS);
 }
 JSONObject job()throws Exception{return new QueueStore(context).enqueue(new JSONObject().put("title","작품").put("url",origin+"/webtoon/7.html"),1);}
 @Test public void imageDownloadWritesHashAndReadingRecordThenSkipsCompleteFile()throws Exception{
  JSONObject job=job();execute(job);QueueStore store=new QueueStore(context);JSONObject done=store.find(job.getString("id"));assertEquals(done.optString("error"),"complete",done.getString("status"));assertEquals(100,done.getInt("progress"));assertEquals(1,received);
  File image=new File(directory,"작품/1화/image.jpg"),record=new File(directory,"작품/1화/_reading_order.json");assertArrayEquals(PNG,java.nio.file.Files.readAllBytes(image.toPath()));assertTrue(record.isFile());assertEquals("1화",new JSONObject(FolderLibraryPlugin.read(record)).getString("episode"));
  store.update(job.getString("id"),new JSONObject().put("status","waiting"));execute(store.find(job.getString("id")));assertEquals("complete",store.status(job.getString("id")));assertEquals(1,received);
 }
 @Test public void refusedImageIsFailedWithStageAndNoCompleteOutput()throws Exception{
  refuse=true;JSONObject job=job();execute(job);JSONObject failure=new QueueStore(context).find(job.getString("id"));assertEquals("failed",failure.getString("status"));assertTrue(failure.getString("error").contains("403"));assertTrue(failure.getString("error").contains("이미지"));assertFalse(new File(directory,"작품/1화/image.jpg").exists());
 }
 @Test public void missingFolderFailsBeforeAnyImageRequest()throws Exception{
  context.getSharedPreferences("library",0).edit().putString("root","").commit();JSONObject job=job();execute(job);JSONObject failure=new QueueStore(context).find(job.getString("id"));assertEquals("failed",failure.getString("status"));assertTrue(failure.getString("error").contains("저장 폴더"));assertEquals(0,received);
 }
 @Test public void referrerMatchesBrowserOriginPolicy()throws Exception{assertEquals("https://example.org/",RenderedPage.referrer("https://example.org/webtoons/7/1.html","https://cdn.example.net/image.jpg"));assertEquals("",RenderedPage.referrer("https://example.org/page","http://example.org/image.jpg"));}
 public static class FixtureProvider extends ContentProvider{
  public boolean onCreate(){return true;}
  File file(String id){return id.equals("root")?directory:new File(directory,id.substring(5));}
  public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort){String id=DocumentsContract.getDocumentId(uri);File parent=file(id);String[] cols=projection==null?new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_LAST_MODIFIED}:projection;MatrixCursor cursor=new MatrixCursor(cols);File[] files=uri.getPath().endsWith("/children")?parent.listFiles():new File[]{parent};if(files==null)return cursor;for(File f:files){Object[] row=new Object[cols.length];String key=f.equals(directory)?"root":"root/"+directory.toPath().relativize(f.toPath()).toString().replace('\\','/');for(int i=0;i<cols.length;i++){String col=cols[i];row[i]=col.equals(DocumentsContract.Document.COLUMN_DOCUMENT_ID)?key:col.equals(DocumentsContract.Document.COLUMN_DISPLAY_NAME)?f.getName():col.equals(DocumentsContract.Document.COLUMN_MIME_TYPE)?(f.isDirectory()?DocumentsContract.Document.MIME_TYPE_DIR:"image/jpeg"):col.equals(DocumentsContract.Document.COLUMN_SIZE)?f.length():col.equals(DocumentsContract.Document.COLUMN_FLAGS)?DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE:f.lastModified();}cursor.addRow(row);}return cursor;}
  public Bundle call(String method,String arg,Bundle extras){if(method.equals("android:createDocument")){Uri parent=extras.getParcelable("uri");String id=DocumentsContract.getDocumentId(parent),name=extras.getString(DocumentsContract.Document.COLUMN_DISPLAY_NAME);File f=new File(file(id),name);try{if(DocumentsContract.Document.MIME_TYPE_DIR.equals(extras.getString(DocumentsContract.Document.COLUMN_MIME_TYPE)))f.mkdir();else f.createNewFile();}catch(IOException e){throw new IllegalStateException(e);}Bundle result=new Bundle();result.putParcelable("uri",DocumentsContract.buildDocumentUriUsingTree(parent,id+"/"+name));return result;}return super.call(method,arg,extras);}
  public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{return ParcelFileDescriptor.open(file(DocumentsContract.getDocumentId(uri)),ParcelFileDescriptor.parseMode(mode));}
  public String getType(Uri uri){return "image/jpeg";}public Uri insert(Uri uri,ContentValues values){return null;}public int delete(Uri uri,String where,String[] args){return 0;}public int update(Uri uri,ContentValues v,String where,String[] args){return 0;}
 }
}

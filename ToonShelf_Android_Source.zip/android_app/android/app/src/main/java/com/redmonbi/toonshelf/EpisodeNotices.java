package com.redmonbi.toonshelf;
import android.content.Context;
import org.json.*;
import org.jsoup.Jsoup;
import java.io.*;
import java.net.URI;
import java.util.*;
final class EpisodeNotices {
    final Context ctx;EpisodeNotices(Context c){ctx=c;}
    synchronized JSONArray check(JSONArray works)throws Exception{
        File file=new File(ctx.getFilesDir(),"episode-notices.json");JSONObject data=file.isFile()?new JSONObject(FolderLibraryPlugin.read(file)):new JSONObject().put("known",new JSONObject()).put("notices",new JSONArray());JSONObject known=data.getJSONObject("known");JSONArray notices=data.getJSONArray("notices");
        for(int i=0;i<Math.min(works.length(),500);i++){JSONObject w=works.getJSONObject(i);String address=w.getString("url");DownloadWorker.validateUrl(address);String key=new URI(address).getPath();List<JSONObject> episodes=DownloadWorker.episodes(Jsoup.connect(address).timeout(20000).maxBodySize(8*1024*1024).get(),w.getString("title"),key);if(episodes.isEmpty())continue;JSONArray previous=known.optJSONArray(key);Set<String> ids=new HashSet<>();if(previous!=null)for(int j=0;j<previous.length();j++)ids.add(previous.getString(j));for(JSONObject ep:episodes){String id=ep.getString("key");if(previous!=null&&!ids.contains(id))notices.put(new JSONObject().put("id",id).put("key",key).put("work",w).put("episode",ep).put("created",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.ROOT).format(new Date())).put("unread",1));ids.add(id);}known.put(key,new JSONArray(ids));}
        while(notices.length()>500)notices.remove(0);android.util.AtomicFile atomic=new android.util.AtomicFile(file);FileOutputStream out=atomic.startWrite();try{out.write(data.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));atomic.finishWrite(out);}catch(Exception e){atomic.failWrite(out);throw e;}return notices;
    }
}

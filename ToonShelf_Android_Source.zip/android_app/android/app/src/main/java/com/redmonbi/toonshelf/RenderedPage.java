package com.redmonbi.toonshelf;
import android.content.Context;
import android.os.*;
import android.webkit.*;
import android.view.ViewGroup;
import org.json.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import java.io.IOException;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;

/** Ordinary isolated WebView rendering. No native JS interface, challenge handling or TLS override. */
final class RenderedPage {
    static final Handler MAIN=new Handler(Looper.getMainLooper());
    static final Semaphore SLOTS=new Semaphore(2);
    interface Check {void run()throws Exception;}
    static Document load(Context context,String address,String selector,Check check)throws Exception{
        if(Looper.myLooper()==Looper.getMainLooper())throw new IllegalStateException("페이지 조회는 배경 작업에서 실행해야 합니다.");
        DownloadWorker.validateUrl(address);check.run();SLOTS.acquire();
        CompletableFuture<Document> result=new CompletableFuture<>();AtomicReference<WebView> holder=new AtomicReference<>();
        Runnable start=()->{try{
            WebView view=new WebView(context);holder.set(view);view.layout(0,0,720,1280);
            view.getSettings().setJavaScriptEnabled(true);view.getSettings().setDomStorageEnabled(true);
            view.getSettings().setAllowFileAccess(false);view.getSettings().setAllowContentAccess(false);
            view.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);view.getSettings().setBlockNetworkImage(true);
            context.getSharedPreferences("library",0).edit().putString("downloadUserAgent",view.getSettings().getUserAgentString()).apply();
            String script="(()=>{if(!document.querySelector("+JSONObject.quote(selector)+"))return null;return JSON.stringify({html:document.documentElement.outerHTML,url:location.href})})()";
            Runnable poll=new Runnable(){String previous="";int stable=0;public void run(){if(result.isDone())return;view.evaluateJavascript(script,raw->{if(result.isDone())return;try{if(raw==null||raw.equals("null")){MAIN.postDelayed(this,350);return;}String decoded=new JSONArray("["+raw+"]").getString(0);JSONObject value=new JSONObject(decoded);String html=value.getString("html");String signature=Jsoup.parse(html).select(selector).outerHtml();stable=signature.equals(previous)?stable+1:0;previous=signature;if(stable<3){MAIN.postDelayed(this,350);return;}if(html.length()>8*1024*1024)throw new IOException("페이지가 너무 큽니다.");DownloadWorker.validateUrl(value.getString("url"));result.complete(Jsoup.parse(html,value.getString("url")));}catch(Exception e){result.completeExceptionally(e);}});}};
            view.setWebViewClient(new WebViewClient(){
                public void onPageFinished(WebView v,String u){if(!result.isDone())MAIN.post(poll);}
                public void onReceivedHttpError(WebView v,WebResourceRequest request,WebResourceResponse response){if(request.isForMainFrame()&&response.getStatusCode()>=400)result.completeExceptionally(new IOException("사이트 접근 오류 ("+response.getStatusCode()+")"));}
                public void onReceivedError(WebView v,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame())result.completeExceptionally(new IOException("사이트 연결 오류: "+error.getDescription()));}
                public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){String scheme=r.getUrl().getScheme();return !"https".equals(scheme)&&!"http".equals(scheme);}
            });view.loadUrl(address);
        }catch(Exception e){result.completeExceptionally(e);}};
        MAIN.post(start);long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(40);
        try{while(true){check.run();try{return result.get(400,TimeUnit.MILLISECONDS);}catch(TimeoutException e){if(System.nanoTime()>deadline)throw new IOException("페이지에서 회차 또는 이미지를 찾지 못했습니다. 사이트 주소와 접근 상태를 확인하세요.");}catch(ExecutionException e){Throwable cause=e.getCause();if(cause instanceof Exception)throw (Exception)cause;throw new IOException("페이지 표시 실패",cause);}}}
        finally{result.cancel(false);MAIN.removeCallbacks(start);MAIN.post(()->{WebView view=holder.get();if(view!=null){view.stopLoading();if(view.getParent() instanceof ViewGroup)((ViewGroup)view.getParent()).removeView(view);view.destroy();}});SLOTS.release();}
    }
    static String cookie(String address)throws Exception{
        CompletableFuture<String> result=new CompletableFuture<>();MAIN.post(()->{try{result.complete(CookieManager.getInstance().getCookie(address));}catch(Exception e){result.completeExceptionally(e);}});return result.get(10,TimeUnit.SECONDS);
    }
    static String referrer(String source,String target)throws Exception{
        java.net.URI a=new java.net.URI(source),b=new java.net.URI(target);
        if("https".equals(a.getScheme())&&"http".equals(b.getScheme()))return "";
        if(a.getScheme().equals(b.getScheme())&&a.getHost().equals(b.getHost())&&a.getPort()==b.getPort())return source;
        return new java.net.URI(a.getScheme(),null,a.getHost(),a.getPort(),"/",null,null).toString();
    }
}

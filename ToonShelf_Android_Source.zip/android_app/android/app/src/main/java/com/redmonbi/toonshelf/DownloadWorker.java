package com.redmonbi.toonshelf;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.*;
import org.json.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.*;

/** Durable Android queue. HTTP refusals remain failures; no access-control bypass. */
public class DownloadWorker extends Worker {
    static final String CHANNEL="toonshelf-downloads";static final java.util.concurrent.locks.ReentrantLock ACTIVE=new java.util.concurrent.locks.ReentrantLock();final QueueStore store;final Context ctx;long rateStart,rateBytes;
    public DownloadWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);ctx=c;store=new QueueStore(c);}
    static void start(Context c){WorkManager.getInstance(c).enqueueUniqueWork("downloads",ExistingWorkPolicy.APPEND_OR_REPLACE,new OneTimeWorkRequest.Builder(DownloadWorker.class).build());}
    static void periodic(Context c){WorkManager.getInstance(c).enqueueUniquePeriodicWork("weekly-list",ExistingPeriodicWorkPolicy.UPDATE,new PeriodicWorkRequest.Builder(DownloadWorker.class,15,TimeUnit.MINUTES).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build());}
    @NonNull @Override public Result doWork(){
        if(!ACTIVE.tryLock())return Result.retry();
        try {
            store.recover();claimSchedule();JSONObject job=store.next();if(job==null)return Result.success();
            NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel(CHANNEL,"작품 다운로드",NotificationManager.IMPORTANCE_LOW));
            Notification note=new NotificationCompat.Builder(ctx,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("ToonShelf 다운로드").setContentText("작품별 진행은 앱에서 확인하세요.").setOngoing(true).build();
            try{setForegroundAsync(Build.VERSION.SDK_INT>=29?new ForegroundInfo(71,note,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC):new ForegroundInfo(71,note)).get();}catch(Exception e){return Result.retry();}
            int count=Math.max(1,Math.min(4,store.read().getJSONObject("settings").optInt("max_parallel",2)));java.util.concurrent.ExecutorService pool=java.util.concurrent.Executors.newFixedThreadPool(count);java.util.List<java.util.concurrent.Future<?>> futures=new ArrayList<>();
            for(int i=0;i<count;i++)futures.add(pool.submit(()->{try{JSONObject claimed;while(!isStopped()&&(claimed=store.claimNext())!=null)run(claimed);}catch(Exception ignored){}}));
            try{for(java.util.concurrent.Future<?> future:futures)future.get();}finally{pool.shutdownNow();}
            return Result.success();
        }catch(Exception e){return Result.retry();}finally{ACTIVE.unlock();}
    }
    void claimSchedule()throws Exception{
        JSONObject settings=store.read().getJSONObject("settings"),schedule=settings.optJSONObject("schedule");if(schedule==null||!schedule.optBoolean("enabled"))return;
        Calendar now=Calendar.getInstance(TimeZone.getTimeZone("Asia/Seoul"));int day=(now.get(Calendar.DAY_OF_WEEK)+5)%7;JSONArray days=schedule.optJSONArray("days");boolean due=false;if(days!=null)for(int i=0;i<days.length();i++)if(days.optInt(i)==day)due=true;
        String[] hm=schedule.optString("time","21:00").split(":");if(!due||hm.length!=2||now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE)<Integer.parseInt(hm[0])*60+Integer.parseInt(hm[1]))return;
        String slot=now.get(Calendar.YEAR)+"-"+now.get(Calendar.DAY_OF_YEAR)+"-"+schedule.optString("time");if(slot.equals(ctx.getSharedPreferences("library",0).getString("scheduleSlot","")))return;
        JSONArray entries=settings.optJSONArray("entries");if(entries!=null)for(int i=0;i<entries.length();i++){JSONObject e=entries.getJSONObject(i);if(!schedule.optString("scope","selected").equals("all")&&!e.optBoolean("selected",e.optInt("selected",1)==1))continue;if(e.optInt("weekday",-1)>=0&&e.optInt("weekday")!=day)continue;store.enqueue(e.getJSONObject("work"),e.optInt("tail",10));}
        ctx.getSharedPreferences("library",0).edit().putString("scheduleSlot",slot).apply();
    }
    void check(String id)throws Exception{if(isStopped())throw new InterruptedException("중단됨");if(!store.status(id).equals("running"))throw new InterruptedException("진행 내용 저장됨");}
    void window(String id)throws Exception {
        JSONObject s=store.settings();if(!s.optBoolean("window_enabled"))return;
        while(true){check(id);Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Asia/Seoul"));int now=c.get(Calendar.HOUR_OF_DAY)*60+c.get(Calendar.MINUTE);int start=minute(s.optString("start","00:00")),end=minute(s.optString("end","00:00"));if(start==end||(start<end?now>=start&&now<end:now>=start||now<end))return;Thread.sleep(1000);s=store.settings();if(!s.optBoolean("window_enabled"))return;}
    }
    static int minute(String s){String[] p=s.split(":");return Integer.parseInt(p[0])*60+Integer.parseInt(p[1]);}
    Document page(String url)throws Exception{validateUrl(url);return Jsoup.connect(url).userAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36").timeout(30000).maxBodySize(8*1024*1024).get();}
    static void validateUrl(String u)throws Exception{URI p=new URI(u);if(!Arrays.asList("https","http").contains(p.getScheme())||p.getHost()==null||p.getUserInfo()!=null)throw new IOException("http/https 사이트 주소를 확인하세요.");}
    static List<JSONObject> episodes(Document doc,String title,String key)throws Exception{
        Map<String,JSONObject> found=new LinkedHashMap<>();Pattern number=Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*화");
        for(Element a:doc.select("a[href]")){String url=a.absUrl("href");if(!url.matches("https?://.+/webtoons/[^/]+/[^/]+\\.html.*"))continue;String text=a.text();Matcher date=Pattern.compile("20\\d{2}-\\d{2}-\\d{2}").matcher(text);String stamp=date.find()?date.group():"";String label=text.replace(stamp,"").trim();if(label.startsWith(title))label=label.substring(title.length()).trim();Matcher n=number.matcher(label);double value=n.find()?Double.parseDouble(n.group(1)):-1;found.put(url,new JSONObject().put("url",url).put("label",QueueStore.name(label.isEmpty()?"회차":label)).put("number",value).put("date",stamp).put("key",key+"|"+new URI(url).getPath()));}
        List<JSONObject> rows=new ArrayList<>(found.values());rows.sort((a,b)->{int c=a.optString("date").compareTo(b.optString("date"));if(c!=0&&!a.optString("date").isEmpty()&&!b.optString("date").isEmpty())return c;c=Double.compare(a.optDouble("number"),b.optDouble("number"));return c!=0?c:Order.compare(a.optString("label"),b.optString("label"));});return rows;
    }
    Uri root()throws Exception{String value=ctx.getSharedPreferences("library",0).getString("root","");if(value.isEmpty())throw new IOException("대표 저장 폴더를 먼저 선택하세요.");Uri t=Uri.parse(value);return DocumentsContract.buildDocumentUriUsingTree(t,DocumentsContract.getTreeDocumentId(t));}
    Uri child(Uri parent,String name,String mime)throws Exception{
        Uri tree=Uri.parse(ctx.getSharedPreferences("library",0).getString("root",""));TreeIndexer index=new TreeIndexer(ctx,tree,new java.util.concurrent.atomic.AtomicBoolean(),(f,d)->{});
        for(TreeIndexer.Entry e:index.children(parent,""))if(e.name.equals(name)){if(mime.equals(DocumentsContract.Document.MIME_TYPE_DIR)&&!e.mime.equals(mime))throw new IOException("폴더와 같은 이름의 파일이 있습니다.");return e.uri;}
        Uri uri=DocumentsContract.createDocument(ctx.getContentResolver(),parent,mime,name);if(uri==null)throw new IOException("저장 파일 생성 실패");return uri;
    }
    Uri existingChild(Uri parent,String name)throws Exception{Uri tree=Uri.parse(ctx.getSharedPreferences("library",0).getString("root",""));for(TreeIndexer.Entry e:new TreeIndexer(ctx,tree,new java.util.concurrent.atomic.AtomicBoolean(),(f,d)->{}).children(parent,""))if(e.name.equals(name))return e.uri;return null;}
    boolean exists(Uri uri)throws Exception{try(android.database.Cursor c=ctx.getContentResolver().query(uri,new String[]{DocumentsContract.Document.COLUMN_SIZE},null,null,null)){return c!=null&&c.moveToFirst()&&c.getLong(0)>0;}}
    void run(JSONObject job)throws Exception{
        String id=job.getString("id");JSONObject work=job.getJSONObject("work");store.update(id,new JSONObject().put("status","running").put("attempt",job.optInt("attempt")+1));long start=System.currentTimeMillis(),total=0;
        try {
            window(id);List<JSONObject> all=episodes(page(work.getString("url")),work.getString("title"),job.getString("key"));if(all.isEmpty())throw new IOException("회차 목록을 찾지 못했습니다. 사이트 구조와 주소를 확인하세요.");
            int tail=job.optInt("tail");List<JSONObject> plan=tail>0?new ArrayList<>(all.subList(Math.max(0,all.size()-tail),all.size())):new ArrayList<>(all);Collections.reverse(plan);
            Uri workDir=child(root(),QueueStore.name(work.getString("title")),DocumentsContract.Document.MIME_TYPE_DIR);int done=0;
            for(JSONObject ep:plan){check(id);window(id);Document doc=page(ep.getString("url"));List<String> images=new ArrayList<>();for(Element img:doc.select("#toon_content_imgs img")){String attr=img.hasAttr("data-original")?"data-original":img.hasAttr("data-src")?"data-src":"src";String url=img.absUrl(attr);if(url.startsWith("http")&&!images.contains(url))images.add(url);}if(images.isEmpty())throw new IOException("본문 이미지를 찾지 못했습니다.");
                Uri episodeDir=child(workDir,ep.getString("label"),DocumentsContract.Document.MIME_TYPE_DIR);JSONArray imageNames=new JSONArray();int position=0;
                for(String url:images){check(id);window(id);position++;String name=QueueStore.name(Uri.parse(url).getLastPathSegment()==null?"image_"+position+".jpg":Uri.parse(url).getLastPathSegment());Uri target=existingChild(episodeDir,name);
                    // Read the existing file dimensions before considering it complete.
                    BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;if(target!=null)try(InputStream in=ctx.getContentResolver().openInputStream(target)){BitmapFactory.decodeStream(in,null,bounds);}boolean valid=bounds.outWidth>=100&&bounds.outHeight>=100;
                    if(!valid){File tmp=File.createTempFile("download-",".image",ctx.getCacheDir());try{long size=fetchImage(url,ep.getString("url"),tmp,id);bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeFile(tmp.getPath(),bounds);if(bounds.outWidth<100||bounds.outHeight<100)continue;
                            if(target==null)target=child(episodeDir,name,"image/jpeg");try(InputStream in=new FileInputStream(tmp);OutputStream out=ctx.getContentResolver().openOutputStream(target,"wt")){if(out==null)throw new IOException("저장 폴더 쓰기 권한이 없습니다.");byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1){check(id);out.write(buffer,0,n);}}total+=size;
                        }finally{tmp.delete();}}
                    imageNames.put(new JSONObject().put("file",name).put("position",position));double progress=100.0*(done+(double)position/images.size())/plan.size();long elapsed=Math.max(1,System.currentTimeMillis()-start);store.update(id,new JSONObject().put("progress",progress).put("bytes",total).put("speed",1000.0*total/elapsed).put("eta",progress>0?elapsed/1000.0*(100-progress)/progress:0).put("episode",ep.getString("label")));
                }
                if(imageNames.length()==0)throw new IOException("100×100 이상인 이미지가 없습니다.");
                JSONObject record=new JSONObject().put("work",work.getString("title")).put("work_key",job.getString("key")).put("work_url",work.getString("url")).put("genre",work.optString("genre")).put("publisher",work.optString("publisher")).put("weekdays",work.optJSONArray("weekdays")==null?new JSONArray():work.optJSONArray("weekdays")).put("episode",ep.getString("label")).put("episode_key",ep.getString("key")).put("sequence",all.indexOf(ep)+1).put("upload_date",ep.optString("date")).put("images",imageNames).put("downloaded",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.ROOT).format(new Date()));
                Uri info=child(episodeDir,"_reading_order.json","application/json");try(OutputStream out=ctx.getContentResolver().openOutputStream(info,"wt")){if(out==null)throw new IOException("회차 기록 저장 실패");out.write(record.toString().getBytes(StandardCharsets.UTF_8));}done++;
            }
            store.update(id,new JSONObject().put("status","complete").put("progress",100).put("bytes",total).put("completed",System.currentTimeMillis()));
        }catch(InterruptedException e){JSONObject current=store.find(id);if(current!=null&&current.optString("status").equals("running"))store.update(id,new JSONObject().put("status","stopped").put("error","중단 후 재개할 수 있습니다."));}
        catch(Exception e){store.update(id,new JSONObject().put("status","failed").put("error",e.getMessage()==null?"다운로드 오류":e.getMessage()));}
    }
    long fetchImage(String url,String referer,File tmp,String id)throws Exception{
        validateUrl(url);HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setRequestProperty("Referer",referer);c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        try{if(c.getResponseCode()!=200)throw new IOException("이미지 접근 오류 ("+c.getResponseCode()+")");long total=0;try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(tmp)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){check(id);total+=n;if(total>32L*1024*1024)throw new IOException("이미지 한 장은 32MB 이하여야 합니다.");out.write(b,0,n);throttle(n,id);}}return total;}finally{c.disconnect();}
    }
    synchronized void throttle(int n,String id)throws Exception{
        JSONObject s=store.settings();double limit=s.optDouble("limit_mib",0);Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Asia/Seoul"));int now=c.get(Calendar.HOUR_OF_DAY)*60+c.get(Calendar.MINUTE);JSONArray rules=s.optJSONArray("rules");if(rules!=null)for(int i=0;i<rules.length();i++){JSONObject r=rules.getJSONObject(i);int a=minute(r.optString("start","00:00")),b=minute(r.optString("end","00:00"));double v=r.optDouble("limit_mib",0);if(v>0&&(a==b||(a<b?now>=a&&now<b:now>=a||now<b)))limit=limit>0?Math.min(limit,v):v;}
        if(limit<=0){rateStart=0;rateBytes=0;return;}if(rateStart==0){rateStart=System.nanoTime();rateBytes=0;}rateBytes+=n;long wait=rateBytes*1000000000L/(long)(limit*1024*1024)-(System.nanoTime()-rateStart);while(wait>0){check(id);Thread.sleep(Math.min(150,Math.max(1,wait/1000000)));wait=rateBytes*1000000000L/(long)(limit*1024*1024)-(System.nanoTime()-rateStart);}if(System.nanoTime()-rateStart>3000000000L){rateStart=0;rateBytes=0;}
    }
}

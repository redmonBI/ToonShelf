package com.redmonbi.toonshelf;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import org.json.*;
import java.io.*;
import java.util.*;

/** Private disposable scan database. Source folders are read-only. */
final class ScanStore implements AutoCloseable {
    final File file;final SQLiteDatabase db;final Set<Cursor> cursors=new HashSet<>();
    ScanStore(Context context)throws IOException {
        file=File.createTempFile("library-scan-",".sqlite",context.getCacheDir());db=SQLiteDatabase.openOrCreateDatabase(file,null);
        db.execSQL("PRAGMA cache_size=-2048");db.execSQL("PRAGMA temp_store=FILE");
        db.execSQL("CREATE TABLE entries(path TEXT PRIMARY KEY,name TEXT,mime TEXT,uri TEXT,size INTEGER,modified INTEGER)");
        db.execSQL("CREATE TABLE records(path TEXT PRIMARY KEY,episode TEXT,parent TEXT,value TEXT)");db.execSQL("CREATE INDEX records_episode ON records(episode)");db.execSQL("CREATE INDEX records_parent ON records(parent)");
        db.execSQL("CREATE TABLE pages(chapter TEXT,value TEXT)");db.execSQL("CREATE INDEX pages_chapter ON pages(chapter)");db.beginTransaction();
    }
    void budget()throws IOException{
        Runtime runtime=Runtime.getRuntime();long available=runtime.maxMemory()-(runtime.totalMemory()-runtime.freeMemory());
        if(available<16L*1024*1024)throw new IOException("메모리가 부족해 검색을 안전하게 중단했습니다. 다른 앱을 닫은 뒤 다시 불러오세요. 이전 보관함은 유지됩니다.");
        if(file.length()>512L*1024*1024)throw new IOException("폴더 검색용 임시 저장 공간 한도에 도달했습니다. 대표 폴더를 나누어 선택하세요.");
    }
    abstract class Rows<V> extends AbstractMap<String,V>{
        final String table;int count;Rows(String t){table=t;}
        abstract V decode(Cursor c);abstract ContentValues encode(String key,V value);
        public V get(Object key){try(Cursor c=db.query(table,null,"path=?",new String[]{String.valueOf(key)},null,null,null)){return c.moveToFirst()?decode(c):null;}}
        public boolean containsKey(Object key){return android.database.DatabaseUtils.longForQuery(db,"SELECT COUNT(*) FROM "+table+" WHERE path=?",new String[]{String.valueOf(key)})>0;}
        public V put(String key,V value){boolean exists=containsKey(key);if(db.insertWithOnConflict(table,null,encode(key,value),SQLiteDatabase.CONFLICT_REPLACE)<0)throw new android.database.sqlite.SQLiteException("폴더 검색 임시 기록 저장 실패");if(!exists)count++;return null;}
        public int size(){return table.equals("entries")?count:(int)android.database.DatabaseUtils.queryNumEntries(db,table);}
        public void clear(){db.delete(table,null,null);count=0;}
        public Set<Map.Entry<String,V>> entrySet(){return new AbstractSet<>(){
            public int size(){return Rows.this.size();}
            public Iterator<Map.Entry<String,V>> iterator(){
                Cursor c=db.query(table,null,null,null,null,null,null);cursors.add(c);
                return new Iterator<>(){Boolean ready=null;String key;
                    public boolean hasNext(){if(ready==null){ready=c.moveToNext();if(!ready){c.close();cursors.remove(c);}}return ready;}
                    public Map.Entry<String,V> next(){if(!hasNext())throw new NoSuchElementException();key=c.getString(0);V value=decode(c);ready=null;return new SimpleImmutableEntry<>(key,value);}
                    public void remove(){db.delete(table,"path=?",new String[]{key});}
                };
            }
        };}
    }
    final Map<String,TreeIndexer.Entry> entries=new Rows<>("entries"){
        TreeIndexer.Entry decode(Cursor c){return new TreeIndexer.Entry(c.getString(0),c.getString(1),c.getString(2),Uri.parse(c.getString(3)),c.getLong(4),c.getLong(5));}
        ContentValues encode(String key,TreeIndexer.Entry e){ContentValues v=new ContentValues();v.put("path",key);v.put("name",e.name);v.put("mime",e.mime);v.put("uri",e.uri.toString());v.put("size",e.size);v.put("modified",e.modified);return v;}
    };
    final Map<String,JSONObject> records=new Rows<>("records"){
        JSONObject decode(Cursor c){try{return new JSONObject(c.getString(3));}catch(JSONException e){throw new IllegalStateException(e);}}
        ContentValues encode(String key,JSONObject value){ContentValues v=new ContentValues();v.put("path",key);v.put("episode",value.optString("episode_key"));v.put("parent",key.substring(0,key.lastIndexOf('/')+1));v.put("value",value.toString());return v;}
    };
    void replaceEpisode(String episode,String parent){db.delete("records","episode=? OR parent=?",new String[]{episode,parent});}
    void addPage(String chapter,JSONObject value){ContentValues v=new ContentValues();v.put("chapter",chapter);v.put("value",value.toString());db.insertOrThrow("pages",null,v);}
    List<JSONObject> pages(String chapter)throws JSONException{List<JSONObject> result=new ArrayList<>();try(Cursor c=db.query("pages",new String[]{"value"},"chapter=?",new String[]{chapter},null,null,null)){while(c.moveToNext()){if(result.size()>=10000)throw new JSONException("한 회차의 이미지가 너무 많습니다. 회차 폴더를 확인하세요.");result.add(new JSONObject(c.getString(0)));}}return result;}
    public void close(){for(Cursor c:cursors)c.close();cursors.clear();if(db.inTransaction())db.endTransaction();db.close();file.delete();}
}

package com.redmonbi.toonshelf;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.provider.DocumentsContract;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Read-only SAF scan. Never changes the selected directory or its PC database. */
public class TreeIndexer {
    public interface Progress {void update(int files,int folders);}
    public static class Entry {
        public String path,name,mime;public Uri uri;public long size,modified;
        Entry(String p,String n,String m,Uri u,long s,long t){path=p;name=n;mime=m;uri=u;size=s;modified=t;}
    }
    final Context context;final Uri tree;final AtomicBoolean cancel;final Progress progress;
    final Map<String,Entry> files=new LinkedHashMap<>();final Set<String> plannedFolders=new HashSet<>(),invalidFolders=new HashSet<>();int folders,imageCount;
    TreeIndexer(Context c,Uri t,AtomicBoolean x,Progress p){context=c;tree=t;cancel=x;progress=p;}
    void check(){if(cancel.get())throw new java.util.concurrent.CancellationException("폴더 검색을 취소했습니다.");}
    public List<Entry> children(Uri folder,String prefix) throws Exception {
        check();List<Entry> result=new ArrayList<>();String id=DocumentsContract.getDocumentId(folder);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,id);
        String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_LAST_MODIFIED};
        try(Cursor cur=context.getContentResolver().query(children,cols,null,null,null)) {
            if(cur==null)throw new IOException("폴더 내용을 읽지 못했습니다.");
            while(cur.moveToNext()) {check();String name=cur.getString(1);if(name==null||name.equals(".")||name.equals("..")||name.contains("/"))continue;
                result.add(new Entry(prefix+name,name,cur.getString(2),DocumentsContract.buildDocumentUriUsingTree(tree,cur.getString(0)),cur.getLong(3),cur.getLong(4)));
            }
        }
        return result;
    }
    public JSONObject scan() throws Exception {
        String rootId=DocumentsContract.getTreeDocumentId(tree);Uri root=DocumentsContract.buildDocumentUriUsingTree(tree,rootId);
        class Folder {Uri uri;String path;int depth;Folder(Uri u,String p,int d){uri=u;path=p;depth=d;}}
        ArrayDeque<Folder> queue=new ArrayDeque<>();queue.add(new Folder(root,"",0));Set<String> visited=new HashSet<>();
        while(!queue.isEmpty()) {check();Folder f=queue.remove();if(!visited.add(f.uri.toString()))continue;if(f.depth>20)throw new IOException("하위 폴더 깊이가 너무 깊습니다.");
            for(Entry e:children(f.uri,f.path)) {
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(e.mime)) {
                    if(!e.name.startsWith(".")&&!Arrays.asList("state","Source","Vendor","PreviousVersion","Updates","node_modules").contains(e.name))queue.add(new Folder(e.uri,e.path+"/",f.depth+1));
                } else if(Order.image(e.name)||e.name.equals(".toonshelf.sqlite3")||e.name.equals("_reading_order.json")||e.name.equals("_toonshelf_manifest.json")){if(!files.containsKey(e.path)&&Order.image(e.name))imageCount++;files.put(e.path,e);}
                validateCounts(imageCount,files.size());
            }
            folders++;progress.update(files.size(),folders);
        }
        Map<String,JSONObject> pc=pcRecords();sidecars(pc);for(JSONObject record:new ReadingRecords(context,tree.toString()).all())try{consume(record,Order.relative(record.getString("relative_folder"))+"/",pc);}catch(Exception ignored){}Map<String,JSONObject> works=new LinkedHashMap<>();Map<String,JSONObject> chapters=new LinkedHashMap<>();Map<String,List<JSONObject>> pages=new HashMap<>();
        for(Entry e:files.values()) {
            check();if(!Order.image(e.name))continue;String[] parts=e.path.split("/");
            String title=parts.length>=3?parts[0]:rootId.substring(rootId.lastIndexOf('/')+1);String chapter=parts.length>=2?parts[parts.length-2]:"1화";
            String wk="/folder/"+title,ck=wk+"|"+chapter;JSONObject meta=pc.get(e.path);String parent=e.path.substring(0,Math.max(0,e.path.lastIndexOf('/')+1));if(plannedFolders.contains(parent)&&meta==null)continue;
            if(meta!=null){wk=meta.optString("work_key",wk);ck=meta.optString("episode_key",ck);title=meta.optString("title",title);chapter=meta.optString("folder",chapter);}
            JSONObject w=works.get(wk);
            if(w==null){w=new JSONObject().put("key",wk).put("title",title).put("url",meta==null?"https://example.invalid"+wk:meta.optString("url","https://example.invalid"+wk)).put("genre",meta==null?"":meta.optString("genre")).put("publisher",meta==null?"":meta.optString("publisher")).put("weekdays",meta==null?new JSONArray():meta.optJSONArray("weekdays")).put("chapters",new JSONArray()).put("nativeFolder",true);works.put(wk,w);}
            JSONObject c=chapters.get(ck);if(c==null){c=new JSONObject().put("id",ck).put("key",ck).put("label",chapter).put("sequence",meta==null?0:meta.optInt("sequence")).put("size",0L).put("count",0).put("nativeFolder",true);chapters.put(ck,c);pages.put(ck,new ArrayList<>());w.getJSONArray("chapters").put(c);}
            if(invalidFolders.contains(parent))c.put("order_error","순서 기록이 손상됐습니다. 사이트 순서를 다시 맞추세요.");c.put("size",c.getLong("size")+e.size);c.put("count",c.getInt("count")+1);
            pages.get(ck).add(new JSONObject().put("uri",e.uri.toString()).put("name",e.name).put("relative_path",e.path).put("position",meta==null?0:meta.optInt("position")));if(meta!=null)c.put("order_source",meta.optString("order_source","download_record"));
            if(meta!=null){c.put("upload_date",meta.optString("upload_date"));c.put("last_downloaded",meta.optString("last_downloaded"));w.put("updated_date",max(w.optString("updated_date"),meta.optString("upload_date")));w.put("last_downloaded",max(w.optString("last_downloaded"),meta.optString("last_downloaded")));if(meta.has("expected_episode_keys"))w.put("expected_episode_keys",meta.getJSONArray("expected_episode_keys"));if(meta.has("expected_images"))c.put("expected_images",meta.getInt("expected_images"));}
        }
        // Missing pages retain their ordinal instead of closing the gap and shifting panels.
        for(Map.Entry<String,JSONObject> item:pc.entrySet())if(!files.containsKey(item.getKey())){JSONObject meta=item.getValue();JSONObject c=chapters.get(meta.optString("episode_key"));if(c!=null&&plannedFolders.contains(item.getKey().substring(0,item.getKey().lastIndexOf('/')+1))){pages.get(c.getString("key")).add(new JSONObject().put("name",item.getKey()).put("position",meta.optInt("position")).put("missing",true));c.put("count",c.getInt("count")+1);c.put("missing",c.optInt("missing")+1);}}
        JSONArray all=new JSONArray();for(JSONObject w:works.values()) {
            JSONArray raw=w.getJSONArray("chapters");List<JSONObject> cs=new ArrayList<>();for(int i=0;i<raw.length();i++)cs.add(raw.getJSONObject(i));
            cs.sort((a,b)->Order.recorded(a.optInt("sequence"),a.optString("label"),b.optInt("sequence"),b.optString("label")));
            JSONArray sorted=new JSONArray();Set<String> complete=new HashSet<>();for(JSONObject c:cs){List<JSONObject> ps=pages.get(c.getString("key"));ps.sort((a,b)->Order.recorded(a.optInt("position"),a.optString("name"),b.optInt("position"),b.optString("name")));Set<Integer> ordinals=new HashSet<>();boolean known=false;for(JSONObject page:ps)if(page.optInt("position")>0){known=true;if(!ordinals.add(page.optInt("position")))c.put("order_error","이미지 순서가 중복됐습니다. 사이트 순서를 다시 맞추세요.");}if(known&&ordinals.size()!=ps.size())c.put("order_error","일부 이미지의 순서가 없습니다. 사이트 순서를 다시 맞추세요.");if(!known)c.put("order_source","filename");c.put("nativePages",new JSONArray(ps));sorted.put(c);if(c.optInt("missing")==0&&!c.has("order_error")&&c.optInt("expected_images",ps.size())==ps.size())complete.add(c.getString("key"));}boolean full=w.has("expected_episode_keys")&&w.getJSONArray("expected_episode_keys").length()>0;if(full){JSONArray expected=w.getJSONArray("expected_episode_keys");for(int i=0;i<expected.length();i++)if(!complete.contains(expected.getString(i)))full=false;}w.put("chapters",sorted).put("complete",full);all.put(w);
        }
        return new JSONObject().put("works",all).put("root",tree.toString()).put("files",files.size()).put("folders",folders).put("checked",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.ROOT).format(new Date()));
    }
    static void validateCounts(int images,int all)throws IOException{if(images>150000)throw new IOException("한 폴더의 이미지가 15만 장을 넘습니다. 폴더를 나누어 선택하세요.");if(all>350000)throw new IOException("한 폴더의 순서 기록과 파일이 너무 많습니다. 폴더를 나누어 선택하세요.");}
    static String max(String a,String b){return a.compareTo(b)>=0?a:b;}
    void consume(JSONObject m,String parent,Map<String,JSONObject> map)throws Exception{
        JSONArray images=m.getJSONArray("images");Set<Integer> seen=new HashSet<>();Set<String> names=new HashSet<>();Map<String,JSONObject> staged=new HashMap<>();int count=0;
        for(int i=0;i<images.length();i++)if(!images.getJSONObject(i).optBoolean("filtered"))count++;
        for(int i=0;i<images.length();i++){
            JSONObject image=images.getJSONObject(i);if(image.optBoolean("filtered"))continue;
            int position=image.optInt("position",i+1);if(position<1||!seen.add(position))throw new IOException("중복 순서");
            String name=Order.relative(image.optString("file"));if(name.isEmpty())name="__missing_"+position+".jpg";if(name.contains("/")||!names.add(name))throw new IOException("중복 이미지 이름");String path=parent+name;
            JSONObject value=new JSONObject().put("work_key",m.optString("work_key","/folder/"+m.getString("work"))).put("episode_key",m.optString("episode_key","/folder/"+m.getString("work")+"|"+m.getString("episode"))).put("title",m.getString("work")).put("url",m.optString("work_url","https://example.invalid/local")).put("folder",m.getString("episode")).put("sequence",m.optInt("sequence")).put("position",position).put("genre",m.optString("genre")).put("publisher",m.optString("publisher")).put("weekdays",m.optJSONArray("weekdays")==null?new JSONArray():m.optJSONArray("weekdays")).put("upload_date",m.optString("upload_date")).put("last_downloaded",m.optString("downloaded")).put("expected_images",count).put("order_source",m.optString("order_source",m.optBoolean("order_verified",true)?"site":"download_record")).put("source_url",image.optString("source_url"));if(m.has("expected_episode_keys"))value.put("expected_episode_keys",m.getJSONArray("expected_episode_keys"));staged.put(path,value);
        }
        map.keySet().removeIf(path->path.startsWith(parent)&&path.substring(parent.length()).indexOf('/')<0);map.putAll(staged);plannedFolders.add(parent);invalidFolders.remove(parent);
    }
    void sidecars(Map<String,JSONObject> map){
        // Work manifests support older PC folders which did not include chapter sidecars.
        for(Entry e:files.values())if(e.name.equals("_toonshelf_manifest.json"))try{
            JSONObject m=readJson(e);JSONObject w=m.getJSONObject("work");String parent=e.path.substring(0,e.path.lastIndexOf('/')+1);JSONArray episodes=m.getJSONArray("episodes");
            for(int j=0;j<episodes.length();j++){JSONObject ep=episodes.getJSONObject(j);JSONArray images=ep.getJSONArray("images_in_reading_order"),ordered=new JSONArray();String folder=null;for(int i=0;i<images.length();i++){JSONObject image=images.getJSONObject(i);String path=Order.relative(image.optString("path"));if(path.isEmpty())continue;String relative=path.startsWith(parent)?path.substring(parent.length()):path;int slash=relative.lastIndexOf('/');if(slash<0)continue;String current=relative.substring(0,slash+1);if(folder!=null&&!folder.equals(current))throw new IOException();folder=current;ordered.put(new JSONObject().put("file",relative.substring(slash+1)).put("position",image.getInt("position")));}if(folder==null)continue;try{consume(new JSONObject(w.toString()).put("work",w.getString("title")).put("work_key",w.getString("key")).put("work_url",w.optString("url")).put("episode",ep.getString("folder")).put("episode_key",ep.getString("key")).put("sequence",ep.optInt("sequence")).put("order_verified",ep.optBoolean("order_verified",ep.optInt("order_verified")==1)).put("images",ordered),parent+folder,map);}catch(Exception ex){invalidFolders.add(parent+folder);}}
        }catch(java.util.concurrent.CancellationException x){throw x;}catch(Exception ignored){}
        for(Entry e:files.values())if(e.name.equals("_reading_order.json")){String parent=e.path.substring(0,e.path.lastIndexOf('/')+1);try{consume(readJson(e),parent,map);}catch(java.util.concurrent.CancellationException x){throw x;}catch(Exception ex){invalidFolders.add(parent);}}
    }
    JSONObject readJson(Entry e)throws Exception{
        if(e.size>16*1024*1024)throw new IOException("순서 기록이 너무 큽니다.");try(InputStream in=context.getContentResolver().openInputStream(e.uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){if(in==null)throw new IOException();byte[] buffer=new byte[16384];int n;while((n=in.read(buffer))!=-1){check();if(out.size()+n>16*1024*1024)throw new IOException();out.write(buffer,0,n);}return new JSONObject(out.toString("UTF-8"));}
    }
    Map<String,JSONObject> pcRecords() throws Exception {
        Map<String,JSONObject> map=new HashMap<>();Entry entry=files.get(".toonshelf.sqlite3");if(entry==null)return map;
        if(entry.size>64L*1024*1024)return map;
        File tmp=File.createTempFile("pc-index-",".db",context.getCacheDir());
        try {
            try(InputStream in=context.getContentResolver().openInputStream(entry.uri);OutputStream out=new FileOutputStream(tmp)){if(in==null)return map;byte[] buffer=new byte[65536];long count=0;int n;while((n=in.read(buffer))!=-1){check();count+=n;if(count>64L*1024*1024)return map;out.write(buffer,0,n);}}
            try(SQLiteDatabase db=SQLiteDatabase.openDatabase(tmp.getPath(),null,SQLiteDatabase.OPEN_READONLY)) {
                Map<String,JSONObject> extra=new HashMap<>();try(Cursor r=db.rawQuery("SELECT key,payload FROM site_metadata",null)){while(r.moveToNext())extra.put(r.getString(0),new JSONObject(r.getString(1)));}catch(Exception ignored){}
                Map<String,JSONArray> expected=new HashMap<>();try(Cursor r=db.rawQuery("SELECT key,episode_keys FROM work_inventory",null)){while(r.moveToNext())expected.put(r.getString(0),new JSONArray(r.getString(1)));}catch(Exception ignored){}
                Map<String,Integer> counts=new HashMap<>();try(Cursor r=db.rawQuery("SELECT episode_key,COUNT(*) FROM images GROUP BY episode_key",null)){while(r.moveToNext())counts.put(r.getString(0),r.getInt(1));}
                String sql="SELECT i.path,i.position,i.last_downloaded,e.key,e.work_key,e.folder,e.sequence,e.upload_date,w.title,w.url,COALESCE(w.genre_override,w.genre),COALESCE(w.publisher_override,w.publisher),w.weekday FROM images i JOIN episodes e ON e.key=i.episode_key JOIN works w ON w.key=e.work_key";
                try(Cursor r=db.rawQuery(sql,null)){while(r.moveToNext()){check();String path;try{path=Order.relative(r.getString(0));}catch(Exception ex){continue;}
                    JSONObject x=extra.get(r.getString(4));JSONArray days=x==null?new JSONArray():x.optJSONArray("weekdays");if(days==null)days=new JSONArray();if(days.length()==0&&r.getInt(12)>=0)days.put(r.getInt(12));
                    JSONObject value=new JSONObject().put("position",r.getInt(1)).put("last_downloaded",r.getString(2)).put("episode_key",r.getString(3)).put("work_key",r.getString(4)).put("folder",r.getString(5)).put("sequence",r.getInt(6)).put("upload_date",r.getString(7)).put("title",r.getString(8)).put("url",r.getString(9)).put("genre",r.getString(10)).put("publisher",r.getString(11)).put("weekdays",days).put("expected_images",counts.get(r.getString(3)));if(expected.containsKey(r.getString(4)))value.put("expected_episode_keys",expected.get(r.getString(4)));map.put(path,value);}}
            }
        }catch(java.util.concurrent.CancellationException ex){throw ex;}catch(Exception ignored){map.clear();}finally{tmp.delete();}
        return map;
    }
}

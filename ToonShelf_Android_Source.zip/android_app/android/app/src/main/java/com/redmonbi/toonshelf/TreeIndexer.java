package com.redmonbi.toonshelf;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.provider.DocumentsContract;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Read-only SAF scan. Never changes the selected directory or its PC database. */
public final class TreeIndexer {
    public interface Progress {void update(int files,int folders);}
    public static class Entry {
        public String path,name,mime;public Uri uri;public long size,modified;
        Entry(String p,String n,String m,Uri u,long s,long t){path=p;name=n;mime=m;uri=u;size=s;modified=t;}
    }
    final Context context;final Uri tree;final AtomicBoolean cancel;final Progress progress;
    final Map<String,Entry> files=new LinkedHashMap<>();int folders;
    TreeIndexer(Context c,Uri t,AtomicBoolean x,Progress p){context=c;tree=t;cancel=x;progress=p;}
    void check(){if(cancel.get())throw new java.util.concurrent.CancellationException("폴더 검색을 취소했습니다.");}
    public List<Entry> children(Uri folder,String prefix) throws Exception {
        check();List<Entry> result=new ArrayList<>();String id=DocumentsContract.getDocumentId(folder);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,id);
        String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_LAST_MODIFIED};
        try(Cursor cur=context.getContentResolver().query(children,cols,null,null,null)) {
            if(cur==null)throw new IOException("폴더 내용을 읽지 못했습니다.");
            while(cur.moveToNext()) {check();String name=cur.getString(1);if(name==null||name.equals(".")||name.equals("..")||name.contains("/"))continue;
                result.add(new Entry(prefix+name,name,cur.getString(2),DocumentsContract.buildDocumentUriUsingTree(tree,cur.getString(0)),cur.getLong(3),cur.getLong(4)));
            }
        }
        return result;
    }
    public JSONObject scan() throws Exception {
        String rootId=DocumentsContract.getTreeDocumentId(tree);Uri root=DocumentsContract.buildDocumentUriUsingTree(tree,rootId);
        class Folder {Uri uri;String path;int depth;Folder(Uri u,String p,int d){uri=u;path=p;depth=d;}}
        ArrayDeque<Folder> queue=new ArrayDeque<>();queue.add(new Folder(root,"",0));Set<String> visited=new HashSet<>();
        while(!queue.isEmpty()) {check();Folder f=queue.remove();if(!visited.add(f.uri.toString()))continue;if(f.depth>20)throw new IOException("하위 폴더 깊이가 너무 깊습니다.");
            for(Entry e:children(f.uri,f.path)) {
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(e.mime)) {
                    if(!e.name.startsWith(".")&&!Arrays.asList("state","Source","Vendor","PreviousVersion","Updates","node_modules").contains(e.name))queue.add(new Folder(e.uri,e.path+"/",f.depth+1));
                } else if(Order.image(e.name)||e.name.equals(".toonshelf.sqlite3")||e.name.equals("_reading_order.json"))files.put(e.path,e);
                if(files.size()>150000)throw new IOException("한 폴더에 파일이 15만 개를 넘습니다. 폴더를 나누어 선택하세요.");
            }
            folders++;progress.update(files.size(),folders);
        }
        Map<String,JSONObject> pc=pcRecords();sidecars(pc);Map<String,JSONObject> works=new LinkedHashMap<>();Map<String,JSONObject> chapters=new LinkedHashMap<>();Map<String,List<JSONObject>> pages=new HashMap<>();
        for(Entry e:files.values()) {
            check();if(!Order.image(e.name))continue;String[] parts=e.path.split("/");
            String title=parts.length>=3?parts[0]:rootId.substring(rootId.lastIndexOf('/')+1);String chapter=parts.length>=2?parts[parts.length-2]:"1화";
            String wk="/folder/"+title,ck=wk+"|"+chapter;JSONObject meta=pc.get(e.path);
            if(meta!=null){wk=meta.optString("work_key",wk);ck=meta.optString("episode_key",ck);title=meta.optString("title",title);chapter=meta.optString("folder",chapter);}
            JSONObject w=works.get(wk);
            if(w==null){w=new JSONObject().put("key",wk).put("title",title).put("url",meta==null?"https://example.invalid"+wk:meta.optString("url","https://example.invalid"+wk)).put("genre",meta==null?"":meta.optString("genre")).put("publisher",meta==null?"":meta.optString("publisher")).put("weekdays",meta==null?new JSONArray():meta.optJSONArray("weekdays")).put("chapters",new JSONArray()).put("nativeFolder",true);works.put(wk,w);}
            JSONObject c=chapters.get(ck);if(c==null){c=new JSONObject().put("id",ck).put("key",ck).put("label",chapter).put("sequence",meta==null?0:meta.optInt("sequence")).put("size",0L).put("count",0).put("nativeFolder",true);chapters.put(ck,c);pages.put(ck,new ArrayList<>());w.getJSONArray("chapters").put(c);}
            c.put("size",c.getLong("size")+e.size);c.put("count",c.getInt("count")+1);
            pages.get(ck).add(new JSONObject().put("uri",e.uri.toString()).put("name",e.name).put("position",meta==null?0:meta.optInt("position")));
            if(meta!=null){w.put("updated_date",max(w.optString("updated_date"),meta.optString("upload_date")));w.put("last_downloaded",max(w.optString("last_downloaded"),meta.optString("last_downloaded")));if(meta.has("expected_episode_keys"))w.put("expected_episode_keys",meta.getJSONArray("expected_episode_keys"));if(meta.has("expected_images"))c.put("expected_images",meta.getInt("expected_images"));}
        }
        JSONArray all=new JSONArray();for(JSONObject w:works.values()) {
            JSONArray raw=w.getJSONArray("chapters");List<JSONObject> cs=new ArrayList<>();for(int i=0;i<raw.length();i++)cs.add(raw.getJSONObject(i));
            cs.sort((a,b)->a.optInt("sequence")>0&&b.optInt("sequence")>0?Integer.compare(a.optInt("sequence"),b.optInt("sequence")):Order.compare(a.optString("label"),b.optString("label")));
            JSONArray sorted=new JSONArray();Set<String> complete=new HashSet<>();for(JSONObject c:cs){List<JSONObject> ps=pages.get(c.getString("key"));ps.sort((a,b)->a.optInt("position")>0&&b.optInt("position")>0?Integer.compare(a.optInt("position"),b.optInt("position")):Order.compare(a.optString("name"),b.optString("name")));c.put("nativePages",new JSONArray(ps));sorted.put(c);if(c.optInt("expected_images",ps.size())==ps.size())complete.add(c.getString("key"));}boolean full=w.has("expected_episode_keys")&&w.getJSONArray("expected_episode_keys").length()>0;if(full){JSONArray expected=w.getJSONArray("expected_episode_keys");for(int i=0;i<expected.length();i++)if(!complete.contains(expected.getString(i)))full=false;}w.put("chapters",sorted).put("complete",full);all.put(w);
        }
        return new JSONObject().put("works",all).put("root",tree.toString()).put("files",files.size()).put("folders",folders).put("checked",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.ROOT).format(new Date()));
    }
    static String max(String a,String b){return a.compareTo(b)>=0?a:b;}
    void sidecars(Map<String,JSONObject> map){for(Entry e:files.values())if(e.name.equals("_reading_order.json")&&e.size<4*1024*1024){try(InputStream in=context.getContentResolver().openInputStream(e.uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){if(in==null)continue;byte[] buffer=new byte[16384];int n;while((n=in.read(buffer))!=-1){check();if(out.size()+n>4*1024*1024)throw new IOException();out.write(buffer,0,n);}JSONObject m=new JSONObject(out.toString("UTF-8"));JSONArray images=m.getJSONArray("images");String parent=e.path.substring(0,e.path.lastIndexOf('/')+1);for(int i=0;i<images.length();i++){JSONObject image=images.getJSONObject(i);String path=parent+Order.relative(image.getString("file"));JSONObject value=new JSONObject().put("work_key",m.optString("work_key","/folder/"+m.getString("work"))).put("episode_key",m.optString("episode_key","/folder/"+m.getString("work")+"|"+m.getString("episode"))).put("title",m.getString("work")).put("url",m.optString("work_url","https://example.invalid/local")).put("folder",m.getString("episode")).put("sequence",m.optInt("sequence")).put("position",image.optInt("position",i+1)).put("genre",m.optString("genre")).put("publisher",m.optString("publisher")).put("weekdays",m.optJSONArray("weekdays")==null?new JSONArray():m.optJSONArray("weekdays")).put("upload_date",m.optString("upload_date")).put("last_downloaded",m.optString("downloaded")).put("expected_images",images.length());if(m.has("expected_episode_keys"))value.put("expected_episode_keys",m.getJSONArray("expected_episode_keys"));map.put(path,value);}}
        catch(java.util.concurrent.CancellationException x){throw x;}catch(Exception ignored){}}
    }
    Map<String,JSONObject> pcRecords() throws Exception {
        Map<String,JSONObject> map=new HashMap<>();Entry entry=files.get(".toonshelf.sqlite3");if(entry==null)return map;
        if(entry.size>64L*1024*1024)return map;
        File tmp=File.createTempFile("pc-index-",".db",context.getCacheDir());
        try {
            try(InputStream in=context.getContentResolver().openInputStream(entry.uri);OutputStream out=new FileOutputStream(tmp)){if(in==null)return map;byte[] buffer=new byte[65536];long count=0;int n;while((n=in.read(buffer))!=-1){check();count+=n;if(count>64L*1024*1024)return map;out.write(buffer,0,n);}}
            try(SQLiteDatabase db=SQLiteDatabase.openDatabase(tmp.getPath(),null,SQLiteDatabase.OPEN_READONLY)) {
                Map<String,JSONObject> extra=new HashMap<>();try(Cursor r=db.rawQuery("SELECT key,payload FROM site_metadata",null)){while(r.moveToNext())extra.put(r.getString(0),new JSONObject(r.getString(1)));}catch(Exception ignored){}
                Map<String,JSONArray> expected=new HashMap<>();try(Cursor r=db.rawQuery("SELECT key,episode_keys FROM work_inventory",null)){while(r.moveToNext())expected.put(r.getString(0),new JSONArray(r.getString(1)));}catch(Exception ignored){}
                Map<String,Integer> counts=new HashMap<>();try(Cursor r=db.rawQuery("SELECT episode_key,COUNT(*) FROM images GROUP BY episode_key",null)){while(r.moveToNext())counts.put(r.getString(0),r.getInt(1));}
                String sql="SELECT i.path,i.position,i.last_downloaded,e.key,e.work_key,e.folder,e.sequence,e.upload_date,w.title,w.url,COALESCE(w.genre_override,w.genre),COALESCE(w.publisher_override,w.publisher),w.weekday FROM images i JOIN episodes e ON e.key=i.episode_key JOIN works w ON w.key=e.work_key";
                try(Cursor r=db.rawQuery(sql,null)){while(r.moveToNext()){check();String path;try{path=Order.relative(r.getString(0));}catch(Exception ex){continue;}
                    JSONObject x=extra.get(r.getString(4));JSONArray days=x==null?new JSONArray():x.optJSONArray("weekdays");if(days==null)days=new JSONArray();if(days.length()==0&&r.getInt(12)>=0)days.put(r.getInt(12));
                    JSONObject value=new JSONObject().put("position",r.getInt(1)).put("last_downloaded",r.getString(2)).put("episode_key",r.getString(3)).put("work_key",r.getString(4)).put("folder",r.getString(5)).put("sequence",r.getInt(6)).put("upload_date",r.getString(7)).put("title",r.getString(8)).put("url",r.getString(9)).put("genre",r.getString(10)).put("publisher",r.getString(11)).put("weekdays",days).put("expected_images",counts.get(r.getString(3)));if(expected.containsKey(r.getString(4)))value.put("expected_episode_keys",expected.get(r.getString(4)));map.put(path,value);}}
            }
        }catch(java.util.concurrent.CancellationException ex){throw ex;}catch(Exception ignored){map.clear();}finally{tmp.delete();}
        return map;
    }
}

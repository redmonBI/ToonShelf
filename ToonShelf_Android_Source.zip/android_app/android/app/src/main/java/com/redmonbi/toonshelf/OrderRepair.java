package com.redmonbi.toonshelf;
import android.content.Context;
import android.net.Uri;
import org.json.*;
import org.jsoup.nodes.*;
import java.net.URI;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Online metadata-only repair. Assets are never renamed, removed or overwritten. */
class OrderRepair {
    interface Progress{void update(String label);}
    final Context context;final String root;final AtomicBoolean cancelled;final Progress progress;
    OrderRepair(Context c,String r,AtomicBoolean x,Progress p){context=c;root=r;cancelled=x;progress=p;}
    void check(){if(cancelled.get())throw new java.util.concurrent.CancellationException("순서 확인을 중단했습니다.");}
    Document page(String address)throws Exception{return RenderedPage.load(context,address,"#toon_content_imgs img",this::check);}
    Document workPage(String address)throws Exception{return RenderedPage.load(context,address,"a[href*=\"/webtoons/\"]",this::check);}
    JSONObject repair(JSONObject work,String base)throws Exception{
        DownloadWorker.validateUrl(base);URI host=new URI(base);JSONArray chapters=work.getJSONArray("chapters"),failures=new JSONArray();int checked=0;
        String workPath=host.getPath().startsWith("/webtoon/")?host.getPath():new URI(work.getString("url")).getPath();if(!workPath.startsWith("/webtoon/"))throw new IOException("작품의 원본 링크를 입력하세요.");work.put("key",workPath);work.put("url",new URI(host.getScheme(),host.getAuthority(),workPath,null,null).toString());List<JSONObject> inventory=DownloadWorker.episodes(workPage(new URI(host.getScheme(),host.getAuthority(),workPath,null,null).toString()),work.getString("title"),work.getString("key"));Map<String,Integer> sequences=new HashMap<>();JSONArray expected=new JSONArray();for(int i=0;i<inventory.size();i++){sequences.put(inventory.get(i).getString("key"),i+1);expected.put(inventory.get(i).getString("key"));}if(inventory.isEmpty())throw new IOException("회차 목록을 찾지 못했습니다. 현재 사이트 주소를 확인하세요.");
        for(int i=0;i<chapters.length();i++){
            check();JSONObject chapter=chapters.getJSONObject(i);progress.update(work.getString("title")+" · "+chapter.getString("label")+" · "+(i+1)+"/"+chapters.length());
            try{
                String episodeKey=chapter.optString("key");int split=episodeKey.indexOf('|');String path=split<0?"":episodeKey.substring(split+1);
                if(!path.startsWith("/webtoons/")){List<JSONObject> matches=new ArrayList<>();for(JSONObject e:inventory)if(e.getString("label").equals(chapter.getString("label")))matches.add(e);if(matches.size()!=1)throw new IOException("회차 이름을 정확히 매칭하지 못했습니다. PC 순서 기록을 함께 옮겨주세요.");episodeKey=matches.get(0).getString("key");path=new URI(matches.get(0).getString("url")).getPath();}
                Document doc=page(new URI(host.getScheme(),host.getAuthority(),path,null,null).toString());JSONArray pages=chapter.getJSONArray("nativePages");Map<String,JSONObject> assets=new HashMap<>();
                for(int j=0;j<pages.length();j++){JSONObject p=pages.getJSONObject(j);if(p.optBoolean("missing"))continue;if(assets.put(p.getString("name"),p)!=null)throw new IOException("같은 파일명이 여러 개입니다.");}
                JSONArray images=new JSONArray();Set<String> urls=new LinkedHashSet<>(),names=new HashSet<>();String folder=null;int missing=0;
                for(Element img:doc.select("#toon_content_imgs img")){String attr=img.hasAttr("data-original")?"data-original":img.hasAttr("data-src")?"data-src":"src",url=img.absUrl(attr);if(!url.startsWith("http")||!urls.add(url))continue;String name=QueueStore.name(Uri.parse(url).getLastPathSegment());if(!names.add(name)){int dot=name.lastIndexOf('.');String suffix=Integer.toHexString(url.hashCode());name=dot>0?name.substring(0,dot)+"_"+suffix+name.substring(dot):name+"_"+suffix;if(!names.add(name))throw new IOException("원본 파일명 중복");}JSONObject asset=assets.get(name);if(asset==null){images.put(new JSONObject().put("file",name).put("position",images.length()+1).put("source_url",url).put("missing",true));missing++;continue;}String relative=asset.optString("relative_path");if(relative.isEmpty())throw new IOException("파일 위치 기록이 없습니다. 폴더를 새로고침하세요.");String parent=relative.substring(0,relative.lastIndexOf('/'));if(folder!=null&&!folder.equals(parent))throw new IOException("회차 파일이 여러 폴더에 있습니다.");folder=parent;images.put(new JSONObject().put("file",name).put("position",images.length()+1).put("source_url",url));}
                if(images.length()==0||folder==null)throw new IOException("본문 이미지가 없습니다.");
                for(String name:assets.keySet())if(!names.contains(name))throw new IOException("기존 이미지의 원본 주소가 변경됐습니다. 원본을 유지하고 매칭을 보류했습니다: "+name);
                if(!sequences.containsKey(episodeKey))throw new IOException("현재 작품의 회차 목록에 없습니다.");
                JSONObject record=new JSONObject().put("version",3).put("work",work.getString("title")).put("work_key",work.getString("key")).put("work_url",work.optString("url")).put("genre",work.optString("genre")).put("publisher",work.optString("publisher")).put("weekdays",work.optJSONArray("weekdays")==null?new JSONArray():work.optJSONArray("weekdays")).put("episode",chapter.getString("label")).put("episode_key",episodeKey).put("sequence",sequences.get(episodeKey)).put("expected_episode_keys",expected).put("order_verified",true).put("order_source","site").put("images",images).put("downloaded",work.optString("last_downloaded")).put("relative_folder",folder);
                new ReadingRecords(context,root).save(record);checked++;
            }catch(java.util.concurrent.CancellationException e){throw e;}catch(Exception e){failures.put(chapter.getString("label")+": "+e.getMessage());}
        }
        return new JSONObject().put("checked",checked).put("unmatched",failures);
    }
}

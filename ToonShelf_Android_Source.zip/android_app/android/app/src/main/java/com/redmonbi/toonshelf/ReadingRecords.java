package com.redmonbi.toonshelf;
import android.content.Context;
import android.util.AtomicFile;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Durable order journal, separate from assets and download completion order. */
final class ReadingRecords {
    final Context context;final String root;
    ReadingRecords(Context c,String r){context=c;root=r;}
    static String hash(String value){try{byte[] data=java.security.MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));StringBuilder text=new StringBuilder();for(byte b:data)text.append(String.format(Locale.ROOT,"%02x",b&255));return text.toString();}catch(Exception e){throw new IllegalStateException(e);}}
    File directory(){File dir=new File(context.getFilesDir(),"reading-plans/"+hash(root));dir.mkdirs();return dir;}
    synchronized void save(JSONObject record)throws Exception{
        AtomicFile file=new AtomicFile(new File(directory(),hash(record.getString("episode_key"))+".json"));
        FileOutputStream out=null;try{out=file.startWrite();out.write(record.toString().getBytes(StandardCharsets.UTF_8));file.finishWrite(out);}catch(Exception e){if(out!=null)file.failWrite(out);throw e;}
    }
    List<JSONObject> all(){List<JSONObject> records=new ArrayList<>();File[] files=directory().listFiles();if(files==null)return records;for(File f:files)if(f.getName().endsWith(".json"))try{records.add(new JSONObject(FolderLibraryPlugin.read(f)));}catch(Exception ignored){}return records;}
}

package com.redmonbi.toonshelf;
import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.os.Build;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;
final class NativeFiles {
    static File export(Context c,String workKey,String chapterKey)throws Exception{
        JSONObject index=new JSONObject(FolderLibraryPlugin.read(new File(c.getFilesDir(),"folder-library.json"))),chapter=null,work=null;JSONArray works=index.getJSONArray("works");
        for(int i=0;i<works.length();i++){JSONObject w=works.getJSONObject(i);if(!w.getString("key").equals(workKey))continue;JSONArray chapters=w.getJSONArray("chapters");for(int j=0;j<chapters.length();j++)if(chapters.getJSONObject(j).getString("key").equals(chapterKey)){work=w;chapter=chapters.getJSONObject(j);}}
        if(chapter==null)throw new IOException("회차 폴더를 새로고침하세요.");if(chapter.optLong("size")>512L*1024*1024)throw new IOException("내보내기는 회차당 512MB까지 지원합니다.");android.os.StatFs space=new android.os.StatFs(c.getCacheDir().getPath());if(space.getAvailableBytes()<chapter.optLong("size")+16L*1024*1024)throw new IOException("임시 저장 공간이 부족합니다.");File destination=new File(c.getCacheDir(),"ToonShelf_"+QueueStore.name(work.getString("title"))+"_"+QueueStore.name(chapter.getString("label"))+".cbz");
        try(ZipOutputStream zip=new ZipOutputStream(new FileOutputStream(destination))){JSONArray images=ChapterPages.all(c,chapter);byte[] b=new byte[65536];for(int i=0;i<images.length();i++){JSONObject page=images.getJSONObject(i);String original=page.getString("name"),ext=original.lastIndexOf('.')>=0?original.substring(original.lastIndexOf('.')):".jpg";zip.putNextEntry(new ZipEntry(String.format(Locale.ROOT,"%05d",i+1)+ext));try(InputStream in=c.getContentResolver().openInputStream(Uri.parse(page.getString("uri")))){if(in==null)throw new IOException("누락 이미지: "+original);int n;while((n=in.read(b))!=-1)zip.write(b,0,n);}zip.closeEntry();}zip.putNextEntry(new ZipEntry("_reading_order.json"));zip.write(new JSONObject().put("work",work.getString("title")).put("episode",chapter.getString("label")).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));zip.closeEntry();}catch(Exception e){destination.delete();throw e;}return destination;
    }
    static File update(Context c,String address,String expected)throws Exception{
        URI parsed=new URI(address);if(!"https".equals(parsed.getScheme())||!"github.com".equals(parsed.getHost())||!parsed.getPath().startsWith("/redmonBI/ToonShelf/releases/download/")||!parsed.getPath().endsWith(".apk")||parsed.getUserInfo()!=null||parsed.getQuery()!=null||!expected.matches("[a-fA-F0-9]{64}"))throw new IOException("공식 APK 업데이트 주소를 확인하세요.");
        File destination=new File(c.getCacheDir(),"ToonShelf_update.apk");HttpURLConnection connection=(HttpURLConnection)new URL(address).openConnection();connection.setConnectTimeout(20000);connection.setReadTimeout(30000);try{if(connection.getResponseCode()!=200)throw new IOException("업데이트 다운로드 실패");long total=0;try(InputStream in=connection.getInputStream();OutputStream out=new FileOutputStream(destination)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){total+=n;if(total>200L*1024*1024)throw new IOException("APK 파일이 너무 큽니다.");out.write(b,0,n);}}String actual;try(InputStream in=new FileInputStream(destination)){actual=ImageLedger.hash(in);}if(!expected.equalsIgnoreCase(actual))throw new IOException("APK 검증값이 일치하지 않습니다.");PackageManager pm=c.getPackageManager();PackageInfo apk=pm.getPackageArchiveInfo(destination.getPath(),(Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES)),installed=pm.getPackageInfo(c.getPackageName(),(Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES));if(apk==null||!c.getPackageName().equals(apk.packageName)||(Build.VERSION.SDK_INT>=28?apk.getLongVersionCode()<installed.getLongVersionCode():apk.versionCode<installed.versionCode)||!(Build.VERSION.SDK_INT>=28?apk.signingInfo!=null&&Arrays.equals(apk.signingInfo.getApkContentsSigners(),installed.signingInfo.getApkContentsSigners()):Arrays.equals(apk.signatures,installed.signatures)))throw new IOException("앱 이름·버전·서명 검증 실패");return destination;}catch(Exception e){destination.delete();throw e;}finally{connection.disconnect();}
    }
}

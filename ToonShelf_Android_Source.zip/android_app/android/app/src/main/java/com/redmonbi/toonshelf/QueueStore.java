package com.redmonbi.toonshelf;
import android.content.Context;
import android.util.AtomicFile;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Private, atomic queue. Source images are outside this metadata store. */
public final class QueueStore {
    private final Context context;private final AtomicFile file;private static final Object LOCK=new Object();private static final Map<String,JSONObject> CACHE=new HashMap<>();
    public QueueStore(Context context){this.context=context;file=new AtomicFile(new File(context.getFilesDir(),"download-queue.json"));}
    private JSONObject cached()throws Exception{String key=file.getBaseFile().getPath();JSONObject state=CACHE.get(key);if(state==null){try{state=new JSONObject(new String(file.readFully(),StandardCharsets.UTF_8));}catch(FileNotFoundException e){state=new JSONObject().put("jobs",new JSONArray()).put("settings",new JSONObject());}CACHE.put(key,state);}return state;}
    public JSONObject read()throws Exception{synchronized(LOCK){return new JSONObject(cached().toString());}}
    public String status(String id)throws Exception{synchronized(LOCK){JSONArray jobs=cached().getJSONArray("jobs");for(int i=0;i<jobs.length();i++)if(jobs.getJSONObject(i).optString("id").equals(id))return jobs.getJSONObject(i).optString("status");return "";}}
    public void write(JSONObject value)throws Exception{synchronized(LOCK){FileOutputStream out=file.startWrite();try{out.write(value.toString().getBytes(StandardCharsets.UTF_8));file.finishWrite(out);CACHE.put(file.getBaseFile().getPath(),value);}catch(Exception e){file.failWrite(out);throw e;}}}
    public JSONObject enqueue(JSONObject work,int tail)throws Exception {synchronized(LOCK){JSONObject state=read();JSONArray jobs=state.getJSONArray("jobs");String key=android.net.Uri.parse(work.getString("url")).getPath();
        for(int i=0;i<jobs.length();i++){JSONObject j=jobs.getJSONObject(i);if(j.getJSONObject("work").optString("url").equals(work.getString("url"))&&Arrays.asList("waiting","running","paused","held","stopped").contains(j.optString("status"))&&j.optInt("tail")==tail)return j;}
        JSONObject j=new JSONObject().put("id",UUID.randomUUID().toString()).put("work",work).put("key",key).put("owner",state.getJSONObject("settings").optString("owner","guest")).put("root",context.getSharedPreferences("library",0).getString("root","" )).put("tail",Math.max(0,Math.min(10000,tail))).put("status","waiting").put("progress",0).put("bytes",0).put("created",System.currentTimeMillis()).put("attempt",0);jobs.put(j);if(jobs.length()>5000){JSONArray trimmed=new JSONArray();for(int i=0;i<jobs.length();i++){JSONObject old=jobs.getJSONObject(i);if(i>=jobs.length()-5000||!Arrays.asList("complete","failed","cancelled").contains(old.optString("status")))trimmed.put(old);}state.put("jobs",trimmed);}write(state);return j;}}
    public void update(String id,JSONObject fields)throws Exception{synchronized(LOCK){JSONObject state=read();JSONArray jobs=state.getJSONArray("jobs");for(int i=0;i<jobs.length();i++){JSONObject j=jobs.getJSONObject(i);if(j.optString("id").equals(id)){for(Iterator<String> keys=fields.keys();keys.hasNext();){String k=keys.next();j.put(k,fields.get(k));}j.put("updated",System.currentTimeMillis());break;}}write(state);}}
    public JSONObject find(String id)throws Exception{JSONArray jobs=read().getJSONArray("jobs");for(int i=0;i<jobs.length();i++)if(jobs.getJSONObject(i).optString("id").equals(id))return jobs.getJSONObject(i);return null;}
    public JSONObject next()throws Exception{JSONArray jobs=read().getJSONArray("jobs");Set<String> active=new HashSet<>();for(int i=0;i<jobs.length();i++){JSONObject j=jobs.getJSONObject(i);if(j.optString("status").equals("running"))active.add(j.optString("root")+"|"+j.optString("key"));}JSONObject next=null;for(int i=0;i<jobs.length();i++){JSONObject j=jobs.getJSONObject(i);if(j.optString("status").equals("waiting")&&!active.contains(j.optString("root")+"|"+j.optString("key"))&&(next==null||j.optLong("priority")>next.optLong("priority")))next=j;}return next;}
    public JSONObject claimNext()throws Exception{synchronized(LOCK){JSONObject job=next();if(job!=null)update(job.getString("id"),new JSONObject().put("status","running"));return job;}}
    public JSONObject settings()throws Exception{synchronized(LOCK){JSONObject source=cached().getJSONObject("settings"),value=new JSONObject();for(String name:new String[]{"limit_mib","rules","window_enabled","start","end","max_parallel","retry_once"})if(source.has(name))value.put(name,source.get(name));return new JSONObject(value.toString());}}
    public void recover()throws Exception{synchronized(LOCK){JSONObject state=read();JSONArray jobs=state.getJSONArray("jobs");boolean changed=false;for(int i=0;i<jobs.length();i++){JSONObject j=jobs.getJSONObject(i);if(j.optString("status").equals("running")){j.put("status","waiting");changed=true;}}if(changed)write(state);}}
    public void configure(JSONObject settings)throws Exception{synchronized(LOCK){JSONObject state=read();state.put("settings",settings);write(state);}}
    public static String name(String value){String s=value.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_").replaceAll("[. ]+$","").trim();return s.isEmpty()?"이름 없음":s.substring(0,Math.min(180,s.length()));}
}

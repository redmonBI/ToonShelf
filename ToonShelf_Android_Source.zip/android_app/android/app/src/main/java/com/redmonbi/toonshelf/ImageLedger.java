package com.redmonbi.toonshelf;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.net.Uri;
import java.io.*;
import java.security.MessageDigest;
final class ImageLedger extends SQLiteOpenHelper {
    ImageLedger(Context c){super(c,"native-images.sqlite",null,1);}
    public void onCreate(SQLiteDatabase db){db.execSQL("CREATE TABLE images(uri TEXT PRIMARY KEY,sha TEXT,complete INTEGER,work_key TEXT,episode_key TEXT,modified INTEGER)");}
    public void onUpgrade(SQLiteDatabase db,int old,int version){}
    static String hash(InputStream in)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)d.update(b,0,n);StringBuilder s=new StringBuilder();for(byte v:d.digest())s.append(String.format(java.util.Locale.ROOT,"%02x",v&255));return s.toString();}
    boolean owned(Uri uri){try(Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM images WHERE uri=?",new String[]{uri.toString()})){return c.moveToFirst();}}
    boolean valid(ContentResolver r,Uri uri)throws Exception{try(Cursor c=getReadableDatabase().rawQuery("SELECT sha,complete FROM images WHERE uri=?",new String[]{uri.toString()})){if(!c.moveToFirst()||c.getInt(1)!=1)return false;try(InputStream in=r.openInputStream(uri)){return in!=null&&c.getString(0).equals(hash(in));}}}
    void record(Uri uri,String sha,boolean complete,String work,String episode){ContentValues v=new ContentValues();v.put("uri",uri.toString());v.put("sha",sha);v.put("complete",complete?1:0);v.put("work_key",work);v.put("episode_key",episode);v.put("modified",System.currentTimeMillis());getWritableDatabase().insertWithOnConflict("images",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
}

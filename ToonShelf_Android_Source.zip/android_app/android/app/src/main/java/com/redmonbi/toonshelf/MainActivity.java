package com.redmonbi.toonshelf;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(android.os.Bundle state){registerPlugin(FolderLibraryPlugin.class);super.onCreate(state);getSharedPreferences("library",0).edit().putBoolean("reading",false).apply();
        getBridge().addWebViewListener(new com.getcapacitor.WebViewListener(){
            @Override public boolean onRenderProcessGone(android.webkit.WebView view,android.webkit.RenderProcessGoneDetail detail){
                getSharedPreferences("library",0).edit().putBoolean("renderer_recovered",true).apply();
                com.getcapacitor.PluginHandle handle=getBridge().getPlugin("FolderLibrary");if(handle!=null&&handle.getInstance() instanceof FolderLibraryPlugin)((FolderLibraryPlugin)handle.getInstance()).abortScan();
                if(view.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)view.getParent()).removeView(view);view.destroy();
                new android.app.AlertDialog.Builder(MainActivity.this).setTitle("화면 복구")
                    .setMessage("앱 화면 처리가 중단되었습니다. 저장한 작품과 설정은 유지됩니다. 화면을 다시 열어 주세요.")
                    .setCancelable(false).setPositiveButton("화면 다시 열기",(dialog,which)->recreate()).show();return true;
            }
        });
    }
}

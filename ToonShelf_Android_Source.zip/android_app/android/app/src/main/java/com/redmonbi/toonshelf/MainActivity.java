package com.redmonbi.toonshelf;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(android.os.Bundle state){registerPlugin(FolderLibraryPlugin.class);super.onCreate(state);}
}

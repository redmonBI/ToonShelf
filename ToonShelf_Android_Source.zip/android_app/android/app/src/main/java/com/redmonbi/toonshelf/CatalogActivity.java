package com.redmonbi.toonshelf;

import android.app.Activity;
import android.os.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;

/** Isolated site renderer. No native JavaScript interface is installed here. */
public class CatalogActivity extends Activity {
    WebView view;TextView status;final Handler main=new Handler(Looper.getMainLooper());int tries=0,day=-1;boolean ended=false,harvesting=false;Map<String,JSONObject> found=new LinkedHashMap<>();
    @Override public void onCreate(Bundle saved){super.onCreate(saved);String url=getIntent().getStringExtra("url");try{DownloadWorker.validateUrl(url);}catch(Exception e){finish();return;}
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);status=new TextView(this);status.setText("사이트 확인 중 · 접근 제한이 나오면 사이트 주소를 확인하세요.");status.setPadding(20,20,20,20);layout.addView(status);Button close=new Button(this);close.setText("취소 · 닫기");close.setOnClickListener(v->finish());layout.addView(close);view=new WebView(this);layout.addView(view,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);
        view.getSettings().setJavaScriptEnabled(true);view.getSettings().setDomStorageEnabled(true);view.getSettings().setAllowFileAccess(false);view.getSettings().setAllowContentAccess(false);view.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        view.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String address){if(!harvesting){harvesting=true;main.postDelayed(()->harvest(),1500);}}@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest request){String s=request.getUrl().getScheme();return !"https".equals(s)&&!"http".equals(s);}});view.loadUrl(url);
    }
    void harvest(){if(ended)return;String script="(()=>{const rows=[];for(const a of document.querySelectorAll('a.toon-link[href]')){if(!/\\/webtoon\\/[^/]+\\.html/.test(new URL(a.href).pathname))continue;const c=a.closest('.card')||a,t=a.title||a.getAttribute('alt')||c.querySelector('h3')?.textContent.replace(/^\\s*UP\\s*/, '').trim();if(!t)continue;const p=c.querySelectorAll('p'),im=a.querySelector('img[data-original],img.thumb2,img.back-img-style'),platform=c.querySelector('.platfrom-style img,.platform-style img');rows.push({title:t,url:a.href,genre:p[0]?.textContent.trim()||'',latest:p[1]?.textContent.trim()||'',publisher:platform?.getAttribute('alt')||platform?.getAttribute('src')||'',thumbnail:im?(im.getAttribute('data-original')||im.src):''});}return JSON.stringify(rows)})()";
        view.evaluateJavascript(script,raw->{if(ended)return;try{String decoded=new JSONArray("["+raw+"]").optString(0,"[]");JSONArray rows=new JSONArray(decoded);for(int i=0;i<rows.length();i++){JSONObject w=rows.getJSONObject(i);String key=android.net.Uri.parse(w.getString("url")).getPath();JSONObject prior=found.get(key);JSONArray days=prior==null?new JSONArray():prior.optJSONArray("weekdays");if(days==null)days=new JSONArray();if(day>=0){boolean has=false;for(int n=0;n<days.length();n++)if(days.optInt(n)==day)has=true;if(!has)days.put(day);}w.put("weekdays",days);w.put("publisher",platform(w.optString("publisher")));found.put(key,w);}
            status.setText("작품 "+found.size()+"개 확인 중");if(rows.length()==0&&day<0&&tries++<25){main.postDelayed(()->harvest(),1500);return;}nextDay();
        }catch(Exception e){status.setText("목록을 읽지 못했습니다. 취소 후 사이트 주소를 확인하세요.");}});
    }
    static String platform(String value){String lower=value.toLowerCase(Locale.ROOT);for(String[] pair:new String[][]{{"naver","네이버"},{"kakao","카카오"},{"daum","다음"},{"lezhin","레진"},{"tomics","투믹스"},{"toptoon","탑툰"}})if(lower.contains(pair[0]))return pair[1];return value.contains("/")?"":value;}
    void nextDay(){if(++day>6){complete();return;}String label=new String[]{"월","화","수","목","금","토","일"}[day];String script="(()=>{for(const e of document.querySelectorAll('button,a,li')){const t=e.textContent.trim();if(t==='"+label+"'||t==='"+label+"요일'){e.click();return true}}return false})()";view.evaluateJavascript(script,result->{if("true".equals(result))main.postDelayed(()->harvest(),1300);else nextDay();});}
    void complete(){try{JSONArray rows=new JSONArray();for(JSONObject w:found.values())rows.put(w);File temp=new File(getFilesDir(),"site-catalog.json.tmp"),target=new File(getFilesDir(),"site-catalog.json");try(FileOutputStream out=new FileOutputStream(temp)){out.write(new JSONObject().put("works",rows).toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));out.getFD().sync();}if(!temp.renameTo(target))throw new IOException();setResult(RESULT_OK);finish();}catch(Exception e){status.setText("목록 저장 실패 · 다시 시도하세요.");}}
    @Override public void onDestroy(){ended=true;main.removeCallbacksAndMessages(null);if(view!=null){view.stopLoading();view.destroy();}super.onDestroy();}
}

package com.redmonbi.toonshelf;

import java.math.BigInteger;
import java.util.Comparator;
import java.util.regex.Pattern;

/** Numeric filename order without locale/float rounding or integer overflow. */
public final class Order {
    private static final Pattern PARTS=Pattern.compile("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
    public static int compare(String a,String b) {
        String[] x=PARTS.split(a.toLowerCase(java.util.Locale.ROOT)),y=PARTS.split(b.toLowerCase(java.util.Locale.ROOT));
        for(int i=0;i<Math.min(x.length,y.length);i++) {
            int c=x[i].matches("\\d+")&&y[i].matches("\\d+")?new BigInteger(x[i]).compareTo(new BigInteger(y[i])):x[i].compareTo(y[i]);
            if(c!=0)return c;
        }
        int c=Integer.compare(x.length,y.length);return c!=0?c:a.compareTo(b);
    }
    public static boolean image(String name) {return name.toLowerCase(java.util.Locale.ROOT).matches(".*\\.(png|jpe?g|webp|gif|avif)$");}
    public static String relative(String path) {
        String p=path.replace('\\','/');
        if(p.startsWith("/")||p.matches("^[A-Za-z]:.*"))throw new IllegalArgumentException("Absolute path");
        for(String part:p.split("/"))if(part.equals(".."))throw new IllegalArgumentException("Parent path");
        return p;
    }
}

package com.redmonbi.toonshelf;
import android.content.*;import android.database.Cursor;import android.net.Uri;import android.provider.DocumentsContract;import java.io.IOException;
final class RootAccess {
 static void validate(Context context,String value)throws Exception{
  if(value==null||value.isEmpty())throw new IOException("대표 저장 폴더가 없습니다. 대표 폴더 불러오기에서 저장할 폴더를 선택하세요.");
  Uri tree=Uri.parse(value);boolean write=false;for(UriPermission grant:context.getContentResolver().getPersistedUriPermissions())if(grant.getUri().equals(tree)&&grant.isWritePermission())write=true;
  if(!write)throw new IOException("저장 폴더 쓰기 권한이 없습니다. 대표 폴더 불러오기에서 폴더를 다시 선택하세요.");
  Uri root=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
  try(Cursor c=context.getContentResolver().query(root,new String[]{DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_FLAGS},null,null,null)){
   if(c==null||!c.moveToFirst()||!DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(0)))throw new IOException("저장 폴더를 찾지 못했습니다. 폴더를 다시 선택하세요.");
   if((c.getInt(1)&DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE)==0)throw new IOException("이 폴더는 새 파일을 저장할 수 없습니다. 쓰기 가능한 폴더를 선택하세요.");
  }
 }
}

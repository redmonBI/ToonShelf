package com.redmonbi.toonshelf;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import java.io.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.*;

@CapacitorPlugin(name="FolderLibrary")
public class FolderLibraryPlugin extends Plugin {
    private final ExecutorService io=Executors.newSingleThreadExecutor();private final AtomicBoolean cancelled=new AtomicBoolean();private boolean scanning;
    SharedPreferences prefs(){return getContext().getSharedPreferences("library",0);}
    File index(){return new File(getContext().getFilesDir(),"folder-library.json");}
    @PluginMethod public void selectRoot(PluginCall call) {
        if(scanning){call.reject("검색을 마친 뒤 폴더를 변경하세요.");return;}
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);startActivityForResult(call,intent,"rootSelected");
    }
    @ActivityCallback private void rootSelected(PluginCall call,ActivityResult result) {
        if(call==null)return;Intent data=result.getData();if(result.getResultCode()!=Activity.RESULT_OK||data==null||data.getData()==null){call.resolve(new JSObject().put("cancelled",true));return;}
        Uri uri=data.getData();try{getContext().getContentResolver().takePersistableUriPermission(uri,data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));prefs().edit().putString("root",uri.toString()).apply();call.resolve(new JSObject().put("root",uri.toString()));}catch(Exception e){call.reject("폴더 접근 권한을 저장하지 못했습니다.",e);}
    }
    @PluginMethod public void status(PluginCall call){String root=prefs().getString("root","");call.resolve(new JSObject().put("root",root).put("version",BuildConfig.VERSION_NAME).put("code",BuildConfig.VERSION_CODE));}
    @PluginMethod public void cachedIndex(PluginCall call){io.execute(()->{try{call.resolve(index().isFile()?new JSObject(read(index())):new JSObject().put("works",new JSArray()));}catch(Exception e){call.reject("보관함 기록을 읽지 못했습니다.",e);}});}
    @PluginMethod public synchronized void scan(PluginCall call) {
        if(scanning){call.reject("이미 폴더를 검색하고 있습니다.");return;}String root=prefs().getString("root","");if(root.isEmpty()){call.reject("대표 폴더를 먼저 선택하세요.");return;}
        scanning=true;cancelled.set(false);io.execute(()->{try{JSONObject value=new TreeIndexer(getContext(),Uri.parse(root),cancelled,(f,d)->notifyListeners("scanProgress",new JSObject().put("files",f).put("folders",d))).scan();
            File tmp=new File(index()+".tmp");try(FileOutputStream out=new FileOutputStream(tmp)){out.write(value.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));out.getFD().sync();}if(!tmp.renameTo(index()))throw new IOException("보관함 저장 실패");call.resolve(new JSObject(value.toString()));
        }catch(Exception e){call.reject(e.getMessage()==null?"폴더 검색 오류":e.getMessage(),e);}finally{scanning=false;}});
    }
    @PluginMethod public void cancelScan(PluginCall call){cancelled.set(true);call.resolve();}
    @PluginMethod public void space(PluginCall call){android.os.StatFs stat=new android.os.StatFs(getContext().getFilesDir().getPath());call.resolve(new JSObject().put("available",stat.getAvailableBytes()).put("total",stat.getTotalBytes()));}
    @PluginMethod public void queue(PluginCall call){io.execute(()->{try{call.resolve(new JSObject(new QueueStore(getContext()).read().toString()));}catch(Exception e){call.reject("대기열 조회 실패",e);}});}
    @PluginMethod public void enqueue(PluginCall call){io.execute(()->{try{JSONObject job=new QueueStore(getContext()).enqueue(call.getObject("work"),call.getInt("tail",0));DownloadWorker.start(getContext());call.resolve(new JSObject(job.toString()));}catch(Exception e){call.reject(e.getMessage(),e);}});}
    @PluginMethod public void configure(PluginCall call){io.execute(()->{try{new QueueStore(getContext()).configure(call.getObject("settings"));DownloadWorker.periodic(getContext());call.resolve();}catch(Exception e){call.reject("예약 설정 저장 실패",e);}});}
    @PluginMethod public void jobAction(PluginCall call){io.execute(()->{try{String id=call.getString("id"),action=call.getString("action");JSONObject fields=new JSONObject();if(action.equals("priority"))fields.put("priority",System.currentTimeMillis());else if(java.util.Arrays.asList("waiting","paused","held","cancelled","stopped").contains(action))fields.put("status",action);else throw new IllegalArgumentException("작업 상태를 확인하세요.");new QueueStore(getContext()).update(id,fields);if(action.equals("waiting"))DownloadWorker.start(getContext());call.resolve();}catch(Exception e){call.reject(e.getMessage(),e);}});}
    @PluginMethod public void loadCatalog(PluginCall call){Intent intent=new Intent(getContext(),CatalogActivity.class);intent.putExtra("url",call.getString("url"));startActivityForResult(call,intent,"catalogSelected");}
    @ActivityCallback private void catalogSelected(PluginCall call,ActivityResult result){if(call==null)return;if(result.getResultCode()!=Activity.RESULT_OK){call.resolve(new JSObject().put("cancelled",true));return;}io.execute(()->{try{call.resolve(new JSObject(read(new File(getContext().getFilesDir(),"site-catalog.json"))));}catch(Exception e){call.reject("사이트 목록 조회 실패",e);}});}
    static String read(File file)throws Exception{try(InputStream in=new FileInputStream(file);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}}
}

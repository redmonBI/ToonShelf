package com.redmonbi.toonshelf;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import java.io.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.*;

@CapacitorPlugin(name="FolderLibrary",permissions={@Permission(alias="notifications",strings={android.Manifest.permission.POST_NOTIFICATIONS})})
public class FolderLibraryPlugin extends Plugin {
    private final ExecutorService io=Executors.newSingleThreadExecutor(),scanner=Executors.newSingleThreadExecutor(),network=Executors.newSingleThreadExecutor();private final AtomicBoolean cancelled=new AtomicBoolean();private volatile boolean scanning;
    SharedPreferences prefs(){return getContext().getSharedPreferences("library",0);}
    void abortScan(){cancelled.set(true);}
    @Override protected void handleOnDestroy(){cancelled.set(true);scanner.shutdownNow();io.shutdownNow();network.shutdownNow();super.handleOnDestroy();}
    File index(){return new File(getContext().getFilesDir(),"folder-library.json");}
    @PluginMethod public void selectRoot(PluginCall call) {
        if(scanning){call.reject("검색을 마친 뒤 폴더를 변경하세요.");return;}
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);startActivityForResult(call,intent,"rootSelected");
    }
    @ActivityCallback private void rootSelected(PluginCall call,ActivityResult result) {
        if(call==null)return;Intent data=result.getData();if(result.getResultCode()!=Activity.RESULT_OK||data==null||data.getData()==null){call.resolve(new JSObject().put("cancelled",true));return;}
        Uri uri=data.getData();try{if((data.getFlags()&Intent.FLAG_GRANT_WRITE_URI_PERMISSION)!=0)getContext().getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);else getContext().getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);prefs().edit().putString("root",uri.toString()).apply();call.resolve(new JSObject().put("root",uri.toString()));}catch(Exception e){call.reject("폴더 접근 권한을 저장하지 못했습니다.",e);}
    }
    @PluginMethod public void status(PluginCall call){String root=prefs().getString("root","");call.resolve(new JSObject().put("root",root).put("version",BuildConfig.VERSION_NAME).put("code",BuildConfig.VERSION_CODE));}
    @PluginMethod public void cachedIndex(PluginCall call){io.execute(()->{try{
        JSObject value=new JSObject().put("works",new JSArray());
        if(index().isFile()&&index().length()<=8L*1024*1024)value=new JSObject(read(index()));
        else if(index().isFile())value.put("needs_rescan",true).put("warning","이전 버전의 큰 보관함 기록을 안전하게 건너뛰었습니다. 대표 폴더를 다시 불러오세요.");
        if(prefs().getBoolean("scan_running",false)&&!scanning){value.put("warning","지난 폴더 검색이 중단되었습니다. 이전 보관함을 유지했으며 다시 검색할 수 있습니다.");prefs().edit().putBoolean("scan_running",false).apply();}
        if(prefs().getBoolean("renderer_recovered",false)){value.put("warning","앱 화면을 복구했습니다. 이전 보관함과 저장한 작품은 유지됩니다.");prefs().edit().putBoolean("renderer_recovered",false).apply();}
        call.resolve(value);
    }catch(Exception e){call.resolve(new JSObject().put("works",new JSArray()).put("warning","보관함 기록을 읽지 못했습니다. 대표 폴더를 다시 불러오세요."));}});}
    @PluginMethod public synchronized void scan(PluginCall call) {
        if(scanning){call.reject("이미 폴더를 검색하고 있습니다.");return;}String root=prefs().getString("root","");if(root.isEmpty()){call.reject("대표 폴더를 먼저 선택하세요.");return;}
        scanning=true;cancelled.set(false);scanner.execute(()->{String generation=null;boolean published=false;long[] last={0};prefs().edit().putBoolean("scan_running",true).commit();try{
            android.os.StatFs space=new android.os.StatFs(getContext().getCacheDir().getPath());if(space.getAvailableBytes()<128L*1024*1024)throw new IOException("폴더 검색용 여유 공간이 부족합니다. 앱 저장 공간을 128MB 이상 확보하세요.");
            JSONObject value=new TreeIndexer(getContext(),Uri.parse(root),cancelled,(f,d)->{long now=android.os.SystemClock.elapsedRealtime();if(now-last[0]>250){last[0]=now;notifyListeners("scanProgress",new JSObject().put("files",f).put("folders",d));}}).scanPaged();generation=value.getString("page_generation");
            if(cancelled.get())throw new java.util.concurrent.CancellationException("폴더 검색을 취소했습니다.");String encoded=value.toString();if(encoded.length()>4*1024*1024)throw new IOException("작품·회차 요약이 너무 큽니다. 대표 폴더를 나누어 주세요.");
            ChapterPages.write(index(),encoded);published=true;ChapterPages.cleanup(getContext(),generation);call.resolve(new JSObject(encoded));
        }catch(OutOfMemoryError e){if(!published&&generation!=null)ChapterPages.delete(new File(getContext().getFilesDir(),"library-pages/"+generation));call.reject("메모리가 부족해 검색을 중단했습니다. 이전 보관함은 유지됩니다. 다른 앱을 닫고 다시 시도하세요.");}
        catch(Exception e){if(!published&&generation!=null)ChapterPages.delete(new File(getContext().getFilesDir(),"library-pages/"+generation));call.reject(e.getMessage()==null?"폴더 검색 오류":e.getMessage(),e);}
        finally{prefs().edit().putBoolean("scan_running",false).apply();scanning=false;}});
    }
    @PluginMethod public void chapterPages(PluginCall call){io.execute(()->{try{call.resolve(new JSObject(ChapterPages.read(getContext(),call.getString("reference"),call.getInt("offset",0)).toString()));}catch(Exception e){call.reject(e.getMessage(),e);}});}
    @PluginMethod public void cancelScan(PluginCall call){cancelled.set(true);call.resolve();}
    @PluginMethod public synchronized void repairOrder(PluginCall call){
        if(scanning){call.reject("진행 중인 폴더 작업을 마친 뒤 실행하세요.");return;}
        String root=prefs().getString("root","");JSObject work=call.getObject("work");String base=call.getString("base_url","");
        if(root.isEmpty()||work==null){call.reject("대표 폴더와 작품을 먼저 선택하세요.");return;}
        scanning=true;cancelled.set(false);scanner.execute(()->{try{JSONObject report=new OrderRepair(getContext(),root,cancelled,label->notifyListeners("orderProgress",new JSObject().put("label",label))).repair(work,base);call.resolve(new JSObject(report.toString()));}catch(Exception e){call.reject(e.getMessage(),e);}finally{scanning=false;}});
    }
    @PluginMethod public void space(PluginCall call){android.os.StatFs stat=new android.os.StatFs(getContext().getFilesDir().getPath());call.resolve(new JSObject().put("available",stat.getAvailableBytes()).put("total",stat.getTotalBytes()));}
    @PluginMethod public void queue(PluginCall call){io.execute(()->{try{call.resolve(new JSObject(new QueueStore(getContext()).read().toString()));}catch(Exception e){call.reject("대기열 조회 실패",e);}});}
    @PluginMethod public void enqueue(PluginCall call){io.execute(()->{try{RootAccess.validate(getContext(),prefs().getString("root",""));JSONObject job=new QueueStore(getContext()).enqueue(call.getObject("work"),call.getInt("tail",0));DownloadWorker.start(getContext());call.resolve(new JSObject(job.toString()));}catch(Exception e){call.reject(e.getMessage(),e);}});}
    @PluginMethod public void configure(PluginCall call){io.execute(()->{try{new QueueStore(getContext()).configure(call.getObject("settings"));DownloadWorker.periodic(getContext());call.resolve();}catch(Exception e){call.reject("예약 설정 저장 실패",e);}});}
    @PluginMethod public void jobAction(PluginCall call){io.execute(()->{try{String id=call.getString("id"),action=call.getString("action");JSONObject fields=new JSONObject();if(action.equals("waiting")){JSONObject old=new QueueStore(getContext()).find(id);if(old==null)throw new IOException("작업을 찾지 못했습니다.");String selected=old.optString("root");if(selected.isEmpty()){selected=prefs().getString("root","");fields.put("root",selected);}RootAccess.validate(getContext(),selected);fields.put("error","").put("phase","다시 시작 준비 중");}if(action.equals("priority"))fields.put("priority",System.currentTimeMillis());else if(java.util.Arrays.asList("waiting","paused","held","cancelled","stopped").contains(action))fields.put("status",action);else throw new IllegalArgumentException("작업 상태를 확인하세요.");new QueueStore(getContext()).update(id,fields);if(action.equals("waiting"))DownloadWorker.start(getContext());call.resolve();}catch(Exception e){call.reject(e.getMessage(),e);}});}
    @PluginMethod public void loadCatalog(PluginCall call){Intent intent=new Intent(getContext(),CatalogActivity.class);intent.putExtra("url",call.getString("url"));startActivityForResult(call,intent,"catalogSelected");}
    @ActivityCallback private void catalogSelected(PluginCall call,ActivityResult result){if(call==null)return;if(result.getResultCode()!=Activity.RESULT_OK){call.resolve(new JSObject().put("cancelled",true));return;}io.execute(()->{try{call.resolve(new JSObject(read(new File(getContext().getFilesDir(),"site-catalog.json"))));}catch(Exception e){call.reject("사이트 목록 조회 실패",e);}});}
    static String read(File file)throws Exception{try(InputStream in=new FileInputStream(file);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}}
    @PluginMethod public void saveSession(PluginCall call){io.execute(()->{try{SecureSession.save(getContext(),call.getString("value",""));call.resolve();}catch(Exception e){call.reject("자동 로그인 저장 실패",e);}});}
    @PluginMethod public void session(PluginCall call){io.execute(()->{try{call.resolve(new JSObject().put("value",SecureSession.load(getContext())));}catch(Exception e){call.reject("저장된 로그인 정보를 다시 설정하세요.",e);}});}
    @PluginMethod public void checkUpdates(PluginCall call){network.execute(()->{try{JSArray works=call.getArray("works",new JSArray());JSONArray notices=new EpisodeNotices(getContext()).check(works);call.resolve(new JSObject().put("notices",notices));}catch(Exception e){call.reject("새 회차 조회 실패: "+e.getMessage(),e);}});}
    @PluginMethod public void exportChapter(PluginCall call){io.execute(()->{try{File output=NativeFiles.export(getContext(),call.getString("work"),call.getString("chapter"));Uri uri=androidx.core.content.FileProvider.getUriForFile(getContext(),getContext().getPackageName()+".fileprovider",output);Intent intent=new Intent(Intent.ACTION_SEND).setType("application/vnd.comicbook+zip").putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);getActivity().runOnUiThread(()->{getActivity().startActivity(Intent.createChooser(intent,"회차 CBZ 저장·공유"));call.resolve();});}catch(Exception e){call.reject("내보내기 실패: "+e.getMessage(),e);}});}
    @PluginMethod public void prepareUpdate(PluginCall call){network.execute(()->{try{NativeFiles.update(getContext(),call.getString("url"),call.getString("sha256"));call.resolve();}catch(Exception e){call.reject("APK 업데이트 준비 실패: "+e.getMessage(),e);}});}
    @PluginMethod public void installUpdate(PluginCall call){getActivity().runOnUiThread(()->{try{File file=new File(getContext().getCacheDir(),"ToonShelf_update.apk");if(!file.isFile())throw new IOException("업데이트 파일을 먼저 준비하세요.");Uri uri=androidx.core.content.FileProvider.getUriForFile(getContext(),getContext().getPackageName()+".fileprovider",file);Intent intent=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);getActivity().startActivity(intent);call.resolve();}catch(Exception e){call.reject("Android 설치 화면을 열지 못했습니다.",e);}});}
    @PluginMethod public void readerState(PluginCall call){prefs().edit().putBoolean("reading",Boolean.TRUE.equals(call.getBoolean("reading",false))).apply();call.resolve();}
    @PluginMethod public void closeApp(PluginCall call){getActivity().runOnUiThread(()->{call.resolve();getActivity().finishAndRemoveTask();});}
    @PluginMethod public void requestAlertsPermission(PluginCall call){if(android.os.Build.VERSION.SDK_INT<33){call.resolve(new JSObject().put("granted",true));return;}requestPermissionForAlias("notifications",call,"alertsGranted");}
    @PermissionCallback private void alertsGranted(PluginCall call){call.resolve(new JSObject().put("granted",getPermissionState("notifications")==PermissionState.GRANTED));}
}

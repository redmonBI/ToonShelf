package com.redmonbi.toonshelf;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import java.io.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.*;

@CapacitorPlugin(name="FolderLibrary",permissions={@Permission(alias="notifications",strings={android.Manifest.permission.POST_NOTIFICATIONS})})
public class FolderLibraryPlugin extends Plugin {
    private final ExecutorService io=Executors.newSingleThreadExecutor(),scanner=Executors.newSingleThreadExecutor(),network=Executors.newSingleThreadExecutor();private final AtomicBoolean cancelled=new AtomicBoolean();private volatile boolean scanning;
    SharedPreferences prefs(){return getContext().getSharedPreferences("library",0);}
    File index(){return new File(getContext().getFilesDir(),"folder-library.json");}
    @PluginMethod public void selectRoot(PluginCall call) {
        if(scanning){call.reject("검색을 마친 뒤 폴더를 변경하세요.");return;}
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);startActivityForResult(call,intent,"rootSelected");
    }
    @ActivityCallback private void rootSelected(PluginCall call,ActivityResult result) {
        if(call==null)return;Intent data=result.getData();if(result.getResultCode()!=Activity.RESULT_OK||data==null||data.getData()==null){call.resolve(new JSObject().put("cancelled",true));return;}
        Uri uri=data.getData();try{if((data.getFlags()&Intent.FLAG_GRANT_WRITE_URI_PERMISSION)!=0)getContext().getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);else getContext().getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);prefs().edit().putString("root",uri.toString()).apply();call.resolve(new JSObject().put("root",uri.toString()));}catch(Exception e){call.reject("폴더 접근 권한을 저장하지 못했습니다.",e);}
    }
    @PluginMethod public void status(PluginCall call){String root=prefs().getString("root","");call.resolve(new JSObject().put("root",root).put("version",BuildConfig.VERSION_NAME).put("code",BuildConfig.VERSION_CODE));}
    @PluginMethod public void cachedIndex(PluginCall call){io.execute(()->{try{call.resolve(index().isFile()?new JSObject(read(index())):new JSObject().put("works",new JSArray()));}catch(Exception e){call.reject("보관함 기록을 읽지 못했습니다.",e);}});}
    @PluginMethod public synchronized void scan(PluginCall call) {
        if(scanning){call.reject("이미 폴더를 검색하고 있습니다.");return;}String root=prefs().getString("root","");if(root.isEmpty()){call.reject("대표 폴더를 먼저 선택하세요.");return;}
        scanning=true;cancelled.set(false);scanner.execute(()->{try{JSONObject value=new TreeIndexer(getContext(),Uri.parse(root),cancelled,(f,d)->notifyListeners("scanProgress",new JSObject().put("files",f).put("folders",d))).scan();
            File tmp=new File(index()+".tmp");try(FileOutputStream out=new FileOutputStream(tmp)){out.write(value.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));out.getFD().sync();}if(!tmp.renameTo(index()))throw new IOException("보관함 저장 실패");call.resolve(new JSObject(value.toString()));
        }catch(Exception e){call.reject(e.getMessage()==null?"폴더 검색 오류":e.getMessage(),e);}finally{scanning=false;}});
    }
    @PluginMethod public void cancelScan(PluginCall call){cancelled.set(true);call.resolve();}
    @PluginMethod public void space(PluginCall call){android.os.StatFs stat=new android.os.StatFs(getContext().getFilesDir().getPath());call.resolve(new JSObject().put("available",stat.getAvailableBytes()).put("total",stat.getTotalBytes()));}
    @PluginMethod public void queue(PluginCall call){io.execute(()->{try{call.resolve(new JSObject(new QueueStore(getContext()).read().toString()));}catch(Exception e){call.reject("대기열 조회 실패",e);}});}
    @PluginMethod public void enqueue(PluginCall call){io.execute(()->{try{RootAccess.validate(getContext(),prefs().getString("root",""));JSONObject job=new QueueStore(getContext()).enqueue(call.getObject("work"),call.getInt("tail",0));DownloadWorker.start(getContext());call.resolve(new JSObject(job.toString()));}catch(Exception e){call.reject(e.getMessage(),e);}});}
    @PluginMethod public void configure(PluginCall call){io.execute(()->{try{new QueueStore(getContext()).configure(call.getObject("settings"));DownloadWorker.periodic(getContext());call.resolve();}catch(Exception e){call.reject("예약 설정 저장 실패",e);}});}
    @PluginMethod public void jobAction(PluginCall call){io.execute(()->{try{String id=call.getString("id"),action=call.getString("action");JSONObject fields=new JSONObject();if(action.equals("waiting")){JSONObject old=new QueueStore(getContext()).find(id);if(old==null)throw new IOException("작업을 찾지 못했습니다.");String selected=old.optString("root");if(selected.isEmpty()){selected=prefs().getString("root","");fields.put("root",selected);}RootAccess.validate(getContext(),selected);fields.put("error","").put("phase","다시 시작 준비 중");}if(action.equals("priority"))fields.put("priority",System.currentTimeMillis());else if(java.util.Arrays.asList("waiting","paused","held","cancelled","stopped").contains(action))fields.put("status",action);else throw new IllegalArgumentException("작업 상태를 확인하세요.");new QueueStore(getContext()).update(id,fields);if(action.equals("waiting"))DownloadWorker.start(getContext());call.resolve();}catch(Exception e){call.reject(e.getMessage(),e);}});}
    @PluginMethod public void loadCatalog(PluginCall call){Intent intent=new Intent(getContext(),CatalogActivity.class);intent.putExtra("url",call.getString("url"));startActivityForResult(call,intent,"catalogSelected");}
    @ActivityCallback private void catalogSelected(PluginCall call,ActivityResult result){if(call==null)return;if(result.getResultCode()!=Activity.RESULT_OK){call.resolve(new JSObject().put("cancelled",true));return;}io.execute(()->{try{call.resolve(new JSObject(read(new File(getContext().getFilesDir(),"site-catalog.json"))));}catch(Exception e){call.reject("사이트 목록 조회 실패",e);}});}
    static String read(File file)throws Exception{try(InputStream in=new FileInputStream(file);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}}
    @PluginMethod public void saveSession(PluginCall call){io.execute(()->{try{SecureSession.save(getContext(),call.getString("value",""));call.resolve();}catch(Exception e){call.reject("자동 로그인 저장 실패",e);}});}
    @PluginMethod public void session(PluginCall call){io.execute(()->{try{call.resolve(new JSObject().put("value",SecureSession.load(getContext())));}catch(Exception e){call.reject("저장된 로그인 정보를 다시 설정하세요.",e);}});}
    @PluginMethod public void checkUpdates(PluginCall call){network.execute(()->{try{JSArray works=call.getArray("works",new JSArray());JSONArray notices=new EpisodeNotices(getContext()).check(works);call.resolve(new JSObject().put("notices",notices));}catch(Exception e){call.reject("새 회차 조회 실패: "+e.getMessage(),e);}});}
    @PluginMethod public void exportChapter(PluginCall call){io.execute(()->{try{File output=NativeFiles.export(getContext(),call.getString("work"),call.getString("chapter"));Uri uri=androidx.core.content.FileProvider.getUriForFile(getContext(),getContext().getPackageName()+".fileprovider",output);Intent intent=new Intent(Intent.ACTION_SEND).setType("application/vnd.comicbook+zip").putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);getActivity().runOnUiThread(()->{getActivity().startActivity(Intent.createChooser(intent,"회차 CBZ 저장·공유"));call.resolve();});}catch(Exception e){call.reject("내보내기 실패: "+e.getMessage(),e);}});}
    @PluginMethod public void prepareUpdate(PluginCall call){network.execute(()->{try{NativeFiles.update(getContext(),call.getString("url"),call.getString("sha256"));call.resolve();}catch(Exception e){call.reject("APK 업데이트 준비 실패: "+e.getMessage(),e);}});}
    @PluginMethod public void installUpdate(PluginCall call){getActivity().runOnUiThread(()->{try{File file=new File(getContext().getCacheDir(),"ToonShelf_update.apk");if(!file.isFile())throw new IOException("업데이트 파일을 먼저 준비하세요.");Uri uri=androidx.core.content.FileProvider.getUriForFile(getContext(),getContext().getPackageName()+".fileprovider",file);Intent intent=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);getActivity().startActivity(intent);call.resolve();}catch(Exception e){call.reject("Android 설치 화면을 열지 못했습니다.",e);}});}
    @PluginMethod public void readerState(PluginCall call){prefs().edit().putBoolean("reading",Boolean.TRUE.equals(call.getBoolean("reading",false))).apply();call.resolve();}
    @PluginMethod public void closeApp(PluginCall call){getActivity().runOnUiThread(()->{call.resolve();getActivity().finishAndRemoveTask();});}
    @PluginMethod public void requestAlertsPermission(PluginCall call){if(android.os.Build.VERSION.SDK_INT<33){call.resolve(new JSObject().put("granted",true));return;}requestPermissionForAlias("notifications",call,"alertsGranted");}
    @PermissionCallback private void alertsGranted(PluginCall call){call.resolve(new JSObject().put("granted",getPermissionState("notifications")==PermissionState.GRANTED));}
}

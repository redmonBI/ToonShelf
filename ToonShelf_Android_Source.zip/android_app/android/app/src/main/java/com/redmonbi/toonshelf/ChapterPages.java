package com.redmonbi.toonshelf;

import android.content.Context;
import android.util.AtomicFile;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Immutable per-generation page chunks. Only small chapter summaries cross the bridge. */
final class ChapterPages {
    static final int CHUNK=128;
    final File directory;final String generation;
    ChapterPages(Context context)throws IOException{generation=UUID.randomUUID().toString();directory=new File(context.getFilesDir(),"library-pages/"+generation);if(!directory.mkdirs())throw new IOException("회차 목록 저장 공간을 만들지 못했습니다.");}
    String save(List<JSONObject> pages)throws Exception{
        String id=UUID.randomUUID().toString();
        for(int offset=0;offset<pages.size();offset+=CHUNK){JSONArray array=new JSONArray();for(int i=offset;i<Math.min(pages.size(),offset+CHUNK);i++)array.put(pages.get(i));write(new File(directory,id+"-"+(offset/CHUNK)+".json"),array.toString());}
        return generation+"/"+id;
    }
    static JSONObject read(Context context,String reference,int offset)throws Exception{
        if(reference==null||!reference.matches("[a-f0-9-]{36}/[a-f0-9-]{36}")||offset<0||offset%CHUNK!=0)throw new IOException("회차 목록 요청을 확인하세요.");
        File file=new File(context.getFilesDir(),"library-pages/"+reference+"-"+(offset/CHUNK)+".json");
        if(!file.isFile()||file.length()>1024*1024)throw new IOException("회차 목록이 없습니다. 대표 폴더를 다시 불러오세요.");
        try(InputStream in=new FileInputStream(file);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buffer=new byte[16384];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>1024*1024)throw new IOException("회차 목록이 너무 큽니다.");out.write(buffer,0,n);}return new JSONObject().put("pages",new JSONArray(out.toString("UTF-8")));}
    }
    static JSONArray all(Context context,JSONObject chapter)throws Exception{
        if(!chapter.has("page_ref"))return chapter.getJSONArray("nativePages");JSONArray result=new JSONArray();int count=chapter.getInt("count");
        if(count>10000)throw new IOException("한 회차의 이미지가 너무 많습니다.");
        for(int offset=0;offset<count;offset+=CHUNK){JSONArray part=read(context,chapter.getString("page_ref"),offset).getJSONArray("pages");for(int i=0;i<part.length();i++)result.put(part.getJSONObject(i));}
        if(result.length()!=count)throw new IOException("회차 이미지 기록 수가 다릅니다. 폴더를 다시 불러오세요.");return result;
    }
    static void write(File file,String value)throws IOException{
        AtomicFile atomic=new AtomicFile(file);FileOutputStream out=atomic.startWrite();try{out.write(value.getBytes(StandardCharsets.UTF_8));atomic.finishWrite(out);}catch(IOException e){atomic.failWrite(out);throw e;}
    }
    void discard(){delete(directory);}
    static void delete(File file){File[] children=file.listFiles();if(children!=null)for(File child:children)delete(child);file.delete();}
    static void cleanup(Context context,String keep){File parent=new File(context.getFilesDir(),"library-pages");File[] dirs=parent.listFiles();if(dirs!=null)for(File dir:dirs)if(dir.isDirectory()&&dir.getName().matches("[a-f0-9-]{36}")&&!dir.getName().equals(keep))delete(dir);}
}
